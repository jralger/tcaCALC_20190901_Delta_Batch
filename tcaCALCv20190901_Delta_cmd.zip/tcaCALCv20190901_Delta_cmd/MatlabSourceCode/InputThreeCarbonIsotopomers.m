function varargout = InputThreeCarbonIsotopomers(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InputThreeCarbonIsotopomers_OpeningFcn, ...
                   'gui_OutputFcn',  @InputThreeCarbonIsotopomers_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
         V = str2double(get(hObject,'String'));
         if V < 0
             hObject.String = ['0'];
         end
         
function hObject = CheckFixGTOne(hObject)
         V = str2double(get(hObject,'String'));
         if V > 1.0
             hObject.String = ['1'];
         end
         
function [handles, A] = DoCallBack(hObject, handles)
    hObject = CheckFixGTOne(hObject);
    hObject = CheckFixNegatives(hObject);
    [handles, A] = ReadUpdateAllThreeCarbonIsotopomers(handles);
    guidata(hObject, handles);
         
function InputThreeCarbonIsotopomers_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
MolID = char(varargin(2));
A = cell2mat(varargin(3));
Z = handles.MoleculeID;
Z.String = MolID;
handles.MoleculeID = Z;

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                               DefineThreeCarbonLabelIndices();

handles.OOO.String = sprintf('%4.2f',A(1, ooo));
handles.XOO.String = sprintf('%4.2f',A(1, xoo));
handles.OXO.String = sprintf('%4.2f',A(1, oxo));
handles.XXO.String = sprintf('%4.2f',A(1, xxo));

handles.OOX.String = sprintf('%4.2f',A(1, oox));
handles.XOX.String = sprintf('%4.2f',A(1, xox));
handles.OXX.String = sprintf('%4.2f',A(1, oxx));
handles.XXX.String = sprintf('%4.2f',A(1, xxx));

[handles, A] = ReadUpdateAllThreeCarbonIsotopomers(handles);

guidata(hObject, handles);
uiwait(handles.figure1);

function varargout = InputThreeCarbonIsotopomers_OutputFcn(hObject, eventdata, handles)
[handles, A] = ReadUpdateAllThreeCarbonIsotopomers(handles);
varargout{1} = A;
close();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% All Create Fcns %%%%%%%%%%%%%%%%%%%%%%
function OOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% End Create Fcns %%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% All callbacks %%%%%%%%%%%%%%%%%%%%%%
function pushbutton1_Callback(hObject, eventdata, handles)
uiresume;

function OOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);
