function D = CombineThreeLabelPools(A, B, C, m, RA, RB)
% This function combines three different molecules (A through C)
% each of A through C is float(nTCATurns, nIsotopomers)
% where 
% nTCATurns is the number of TCA turns being simulated by the calling
% program
% nIsotopomers is the total number of isotopomers 
% eg Glu = float(35, 64) for a 35 TCA turn simulations
% m is the tTCA cycle turn number
% RA - RB are the proportions A - B contributes to the final mixture
% RC is computed (RA + RB + RC  = 1.0)
% returns the weighted average of the five molecules

% note that this function does not check that the dimensions of the input
% molecules are matched. Error will occur if they are not matched.
RC = 1.0 - RA - RB;

D = C;
D(m, :) = (RA*A(m,:)) + (RB*B(m,:)) + (RC*C(m, :));
end

