function [handles, A] = ReadUpdateAllFourCarbonIsotopomers(handles)

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                      DefineFourCarbonLabelIndices();

A = zeros(1,16);

A(1, xooo) = str2double(handles.XOOO.String);
A(1, oxoo) = str2double(handles.OXOO.String);
A(1, xxoo) = str2double(handles.XXOO.String);

A(1, ooxo) = str2double(handles.OOXO.String);
A(1, xoxo) = str2double(handles.XOXO.String);
A(1, oxxo) = str2double(handles.OXXO.String);
A(1, xxxo) = str2double(handles.XXXO.String);

A(1, ooox) = str2double(handles.OOOX.String);
A(1, xoox) = str2double(handles.XOOX.String);
A(1, oxox) = str2double(handles.OXOX.String);
A(1, xxox) = str2double(handles.XXOX.String);

A(1, ooxx) = str2double(handles.OOXX.String);
A(1, xoxx) = str2double(handles.XOXX.String);
A(1, oxxx) = str2double(handles.OXXX.String);
A(1, xxxx) = str2double(handles.XXXX.String);

A = UpdateUnLabelledIsotopomer(A);

if A(1, oooo) < 0
    A = zeros(1, 16);
    A = UpdateUnLabelledIsotopomer(A);
end

handles.OOOO.String = sprintf('%4.2f', A(1, oooo));
handles.XOOO.String = sprintf('%4.2f', A(1, xooo));
handles.OXOO.String = sprintf('%4.2f', A(1, oxoo));
handles.XXOO.String = sprintf('%4.2f', A(1, xxoo));

handles.OOXO.String = sprintf('%4.2f', A(1, ooxo));
handles.XOXO.String = sprintf('%4.2f', A(1, xoxo));
handles.OXXO.String = sprintf('%4.2f', A(1, oxxo));
handles.XXXO.String = sprintf('%4.2f', A(1, xxxo));

handles.OOOX.String = sprintf('%4.2f', A(1, ooox));
handles.XOOX.String = sprintf('%4.2f', A(1, xoox));
handles.OXOX.String = sprintf('%4.2f', A(1, oxox));
handles.XXOX.String = sprintf('%4.2f', A(1, xxox));

handles.OOXX.String = sprintf('%4.2f', A(1, ooxx));
handles.XOXX.String = sprintf('%4.2f', A(1, xoxx));
handles.OXXX.String = sprintf('%4.2f', A(1, oxxx));
handles.XXXX.String = sprintf('%4.2f', A(1, xxxx));

end




