function FID = BuildFIDOneSignal(Signal, ScannerFreqMHz, SampleTimesSec, ...
                   CenterPPM)
              
% DeltaPPM = Signal.FreqPPM - CenterPPM;
DeltaPPM = CenterPPM - Signal.FreqPPM;
FreqHz = ScannerFreqMHz*DeltaPPM;
Amplitude = Signal.Amplitude;
PhaseDegrees = Signal.PhaseDeg;
ImagSign = Signal.ImagSign;
if strcmp(Signal.Shape, 'Lorentz')
    R2 = Signal.ShapeParams(1);
    FID = CalculateDecayingComplexExponential(SampleTimesSec, R2, FreqHz, ...
               Amplitude, PhaseDegrees, ImagSign);
end         
           
% test plots
% X = SampleTimesSec;
% Y = FID;
% maxX = 0.1;
% Y = Y(X < maxX);
% X = X(X < maxX);
%  
% ReY = real(Y);
% ImY = imag(Y);
% 
% plot(X,ReY, 'g-', X, ImY, 'r-');Dummy = 1;
%            
% dummy = 1.0;           
           
end


