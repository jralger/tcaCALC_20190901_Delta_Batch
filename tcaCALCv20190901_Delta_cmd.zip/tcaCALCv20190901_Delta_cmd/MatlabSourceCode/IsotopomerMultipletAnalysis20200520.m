function varargout = IsotopomerMultipletAnalysis20200520(varargin)
% IsotopomerMultipletAnalysis20200520 MATLAB code for IsotopomerMultipletAnalysis20200520.fig
%      IsotopomerMultipletAnalysis20200520, by itself, creates a new IsotopomerMultipletAnalysis20200520 or raises the existing
%      singleton*.
%
%      H = IsotopomerMultipletAnalysis20200520 returns the handle to a new IsotopomerMultipletAnalysis20200520 or the handle to
%      the existing singleton*.
%
%      IsotopomerMultipletAnalysis20200520('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IsotopomerMultipletAnalysis20200520.M with the given input arguments.
%
%      IsotopomerMultipletAnalysis20200520('Property','Value',...) creates a new IsotopomerMultipletAnalysis20200520 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before IsotopomerMultipletAnalysis20200520_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to IsotopomerMultipletAnalysis20200520_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help IsotopomerMultipletAnalysis20200520

% Last Modified by GUIDE v2.5 20-May-2020 12:52:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IsotopomerMultipletAnalysis20200520_OpeningFcn, ...
                   'gui_OutputFcn',  @IsotopomerMultipletAnalysis20200520_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before IsotopomerMultipletAnalysis20200520 is made visible.
function IsotopomerMultipletAnalysis20200520_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to IsotopomerMultipletAnalysis20200520 (see VARARGIN)

% Choose default command line output for IsotopomerMultipletAnalysis20200520
handles.output = hObject;


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes IsotopomerMultipletAnalysis20200520 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = IsotopomerMultipletAnalysis20200520_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
contents = cellstr(get(hObject,'String'));
Value = contents{get(hObject,'Value')};
if strcmp(Value,'Fit Multiplets')
     handles.UserInstruct.String = 'Please wait: Fitting spectrum ......';
     pause(1);
     DN = handles.DN;
     BMPDN = [DN, 'IMA1Results'];
     R = rmdir(BMPDN, 's');
     R = mkdir(BMPDN);
     handles = BuildAllDefaultMultiplets(handles);
     Molecules = handles.Molecules;
     Spectrum = handles.Spectrum; 
     MinFitR2Edit = handles.MinFitR2Edit;
     MinFitR2 = str2double(MinFitR2Edit.String);
     MaxFitR2Edit = handles.MaxFitR2Edit;
     MaxFitR2 = str2double(MaxFitR2Edit.String);
     Molecules = RunIndependentMoleculeFits(Spectrum, Molecules, ...
         MinFitR2, MaxFitR2);
     Molecules = FitAllMultipletConcs(Spectrum, Molecules, ...
                    handles.SingletDisplayPPMWidth);
     Molecules = ScaleMultipletFits(Molecules);
     DisplaySaveMoleculeFits(BMPDN, Spectrum, Molecules);   
%      DisplaySaveMoleculeFitsDiff(BMPDN, Spectrum, Molecules);
%      DisplaySaveMoleculeFitsAll(BMPDN, Spectrum, Molecules);
%     DisplaySaveStackedMoleculeFits(BMPDN, Spectrum, Molecules);
     DumpMultipletResultsCSV(Molecules, BMPDN);
     handles.UserInstruct.String = 'Spectrum fitting completed!';
     pause(1);
end


if strcmp(Value, 'Load FID, Reconstruct & AutoPhase')
      R = SetDefaultChemicalShifts();
      handles.LacEstFreqsPPM = R.LacEstFreqsPPM;
      handles.GluEstFreqsPPM = R.GluEstFreqsPPM;
      handles.AspEstFreqsPPM = R.AspEstFreqsPPM;
      handles.bHBEstFreqsPPM = R.bHBEstFreqsPPM;
      
      R = SetDefaultJs();
      handles.AlaEstJAHz = R.LacEstJAHz;
      handles.LacEstJAHz = R.LacEstJAHz;
      handles.GluEstJAHz = R.GluEstJAHz;
      handles.AspEstJAHz = R.AspEstJAHz;
      handles.bHBEstJAHz = R.bHBEstJAHz;
      handles.GlcEstJAHz = R.GlcEstJAHz;
      handles.MAGEstJAHz = R.MAGEstJAHz;
      
      IsoShiftArr = SetDefaultIsotopeShifts();
      handles.IsoShifts = IsoShiftArr;
     
      handles.SingletDisplayPPMWidth = 2.0;
      handles.DefaultMolConc = 1.0;
      handles.GlobalR2 = 3.0;


          [FN,DN,FilterIndex] = uigetfile('*','Identify Spectrum Filename:');
%         DN = 'C:\Users\Jeffry R Alger\Desktop\tcaCALCEval20190909\BrukerTopSpin\13C_DIO_Control_Liver_1\pdata\1\';
%         FN = '1r';
%       DN = 'C:\Users\Jeffry R Alger\Desktop\Mukundan20200518\SpectrumCSV\';
%       FN = 'inf-24h_1_re_im_comma.csv';
      R = strfind(DN, 'SpectrumCSV');
      if R ~= 0
          SpectrumFN = [DN, FN];
          Spectrum = ReadCSVSpectrum(SpectrumFN);
          handles.DN = DN;
      end
      R = strfind(DN, 'BrukerTopSpin');
      if R ~= 0
          rfile = [DN, '1r'];
          ifile = [DN, '1i'];
          procfile = [DN, 'proc'];
          Spectrum = ReadTopSpinSpectrum(rfile, ifile, procfile);
          handles.DN = DN;
      end
      
      R = strfind(DN, 'BrukerTopSpinFullSW');
      if R ~= 0
          rfile = [DN, '1r'];
          ifile = [DN, '1i'];
          procfile = [DN, 'proc'];
          Spectrum = ReadTopSpinSpectrumFullSW(rfile, ifile, procfile);
          handles.DN = DN;
      end
      
      R = strfind(DN, 'Agilent');
      if R ~= 0
          SpectrumFN = [DN, FN];
          Spectrum = LoadProcessFID(SpectrumFN);
          handles.DN = DN;
      end

      ax1 = handles.axes1;

      CS = Spectrum.FreqDomainData;
      ReCS = real(CS);
      ppmtable = Spectrum.PPMTable;
      plot(ppmtable, ReCS, 'r-');
      ax1 = gca();
      ax1.XLim = [0 200];    
      ax1.XMinorTick = 'on';            
      ax1.XLabel.String = 'PPM';
      ax1.YAxis.Visible = 'off';
      ax1.XDir = 'reverse';
      ax1.Visible = 'on';
      
      handles.Spectrum = Spectrum;
      handles.axes1 = ax1;
      handles.RefSet = 0;
      handles.UserInstruct.String = 'Assign Lac C3 S';
      guidata(hObject, handles);

end




% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function LBPPMedit_Callback(hObject, eventdata, handles)
% hObject    handle to LBPPMedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LBPPMedit as text
%        str2double(get(hObject,'String')) returns contents of LBPPMedit as a double
LBPPM = str2double(get(hObject,'String'));
LBPPM = 0.0;
handles.LBPPM = LBPPM;
LBPPMedit = handles.LBPPMedit;
LBPPMedit.String = num2str(LBPPM, '% 5.2f');
handles.LBPPMedit = LBPPMedit;


% --- Executes during object creation, after setting all properties.
function LBPPMedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LBPPMedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
    
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');

end



function SWPPMEdit_Callback(hObject, eventdata, handles)
% hObject    handle to SWPPMEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SWPPMEdit as text
%        str2double(get(hObject,'String')) returns contents of SWPPMEdit as a double


% --- Executes during object creation, after setting all properties.
function SWPPMEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SWPPMEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on mouse press over axes background.
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

T = eventdata;

% --- Executes on button press in Lac_C1_S.
function Lac_C1_S_Callback(hObject, eventdata, handles)
SingletID = 'Lac C1 S';
LIdx = 1;
EstFreqsPPM = handles.LacEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.LacEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.LacEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Lac C1 D12');
PPMs(2) = CenterFreqPPM + HJ12 + dPPM;
PPMs(3) = CenterFreqPPM - HJ12 + dPPM;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Lac_C1_D.
function Lac_C1_D_Callback(hObject, eventdata, handles)
DoubletID = 'Lac C1 D';
LIdx = 1;
JCIdx = 2;
FreqsPPM = handles.LacEstFreqsPPM;
JAHz = handles.LacEstJAHz;
handles.XLacEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Lac_C2S.
function Lac_C2S_Callback(hObject, eventdata, handles)
SingletID = 'Lac C2 S';
LIdx = 2;
EstFreqsPPM = handles.LacEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.LacEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.LacEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J23 = JA(2,3);
HJ23 = J23/2.0;
dPPM = GetIsotopeShift(handles, 'Lac C2 D23');
PPMs(2) = CenterFreqPPM + HJ23 + dPPM;
PPMs(3) = CenterFreqPPM - HJ23 + dPPM;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Lac C2 D12');
PPMs(4) = CenterFreqPPM + HJ12 + dPPM;
PPMs(5) = CenterFreqPPM - HJ12 + dPPM;
dPPM = GetIsotopeShift(handles, 'Lac C2 Q');
PPMs(6) = CenterFreqPPM + dPPM + HJ12 + HJ23;
PPMs(7) = CenterFreqPPM + dPPM + HJ12 - HJ23;
PPMs(8) = CenterFreqPPM + dPPM - HJ12 + HJ23;
PPMs(9) = CenterFreqPPM + dPPM - HJ12 - HJ23;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Lac_C2_D12.
function Lac_C2_D12_Callback(hObject, eventdata, handles)
DoubletID = 'Lac C2 D12';
LIdx = 2;
JCIdx = 1;
FreqsPPM = handles.LacEstFreqsPPM;
JAHz = handles.LacEstJAHz;
handles.LacEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);;


% --- Executes on button press in Lac_C2_D23.
function Lac_C2_D23_Callback(hObject, eventdata, handles)
DoubletID = 'Lac C2 D23';
LIdx = 2;
JCIdx = 3;
FreqsPPM = handles.LacEstFreqsPPM;
JAHz = handles.LacEstJAHz;
handles.LacEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Lac_C2_Q.
function Lac_C2_Q_Callback(hObject, eventdata, handles)
QuartetID = 'Lac C2 Q';
LIdx = 2;
JCIdxLow = 3;
JCIdxHigh = 1;
JAHz = handles.LacEstJAHz;
FreqsPPM = handles.LacEstFreqsPPM;
handles.LacEstFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Lac_C3S.
function Lac_C3S_Callback(hObject, eventdata, handles)
SingletID = 'Lac C3 S';
LIdx = 3;
EstFreqsPPM = handles.LacEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
[handles, Singlet] = SetPPMRefToSinglet(handles, Singlet, EstFreqPPM);
PPMLow = Singlet.CenterFreqPPM - (handles.SingletDisplayPPMWidth/2.0);
PPMHigh = PPMLow + handles.SingletDisplayPPMWidth;
ax1 = handles.axes1;
JAHz = handles.LacEstJAHz;
J = JAHz(2,3);
Spectrum = handles.Spectrum;
J = J/Spectrum.ScannerFreqMHz;
HJ = J/2.0;
dPPM = GetIsotopeShift(handles, 'Lac C3 D');
SPPM = Singlet.CenterFreqPPM;
clear PPMs;
PPMs = [SPPM, SPPM + HJ + dPPM, SPPM - HJ + dPPM];
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
handles.axes1 = ax1;
guidata(hObject, handles);


% --- Executes on button press in Lac_C3D.
function Lac_C3D_Callback(hObject, eventdata, handles)
DoubletID = 'Lac C3 D';
LIdx = 3;
JCIdx = 2;
FreqsPPM = handles.LacEstFreqsPPM;
JAHz = handles.LacEstJAHz;
handles.LacEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C1S.
function Glu_C1S_Callback(hObject, eventdata, handles)
SingletID = 'Glu C1 S';
LIdx = 1;
EstFreqsPPM = handles.GluEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.GluEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.GluEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C1 D12');
PPMs(2) = CenterFreqPPM + HJ12 + dPPM;
PPMs(3) = CenterFreqPPM - HJ12 + dPPM;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C1D.
function Glu_C1D_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C1 D';
LIdx = 1;
JCIdx = 2;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C2S.
function Glu_C2S_Callback(hObject, eventdata, handles)
SingletID = 'Glu C2 S';
LIdx = 2;
EstFreqsPPM = handles.GluEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.GluEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;

ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.GluEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C2 D12');
PPMs(2) = CenterFreqPPM + HJ12 + dPPM;
PPMs(3) = CenterFreqPPM - HJ12 + dPPM;
J23 = JA(2,3);
HJ23 = J23/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C2 D23');
PPMs(4) = CenterFreqPPM + HJ23 + dPPM;
PPMs(5) = CenterFreqPPM - HJ23 + dPPM;
dPPM = GetIsotopeShift(handles, 'Glu C2 Q');
PPMs(6) = CenterFreqPPM + dPPM + HJ12 + HJ23;
PPMs(7) = CenterFreqPPM + dPPM + HJ12 - HJ23;
PPMs(8) = CenterFreqPPM + dPPM - HJ12 + HJ23;
PPMs(9) = CenterFreqPPM + dPPM - HJ12 - HJ23;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C2D12.
function Glu_C2D12_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C2 D12';
LIdx = 2;
JCIdx = 1;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C2D23.
function Glu_C2D23_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C2 D23';
LIdx = 2;
JCIdx = 3;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C2Q.
function Glu_C2Q_Callback(hObject, eventdata, handles)
QuartetID = 'Glu C2 Q';
LIdx = 2;
JCIdxLow = 3;
JCIdxHigh = 1;
JAHz = handles.GluEstJAHz;
FreqsPPM = handles.GluEstFreqsPPM;
handles.GluFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C3S.
function Glu_C3S_Callback(hObject, eventdata, handles)
SingletID = 'Glu C3 S';
LIdx = 3;
EstFreqsPPM = handles.GluEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.GluEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.GluEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J23 = JA(2,3);
HJ23 = J23/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C3 D23');
PPMs(2) = CenterFreqPPM + HJ23 + dPPM;
PPMs(3) = CenterFreqPPM - HJ23 + dPPM;
J34 = JA(3,4);
HJ34 = J34/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C3 D34');
PPMs(4) = CenterFreqPPM + HJ34 + dPPM;
PPMs(5) = CenterFreqPPM - HJ34 + dPPM;
dPPM = GetIsotopeShift(handles, 'Glu C3 T');
PPMs(6) = CenterFreqPPM + dPPM + HJ34 + HJ23;
PPMs(7) = CenterFreqPPM + dPPM + HJ34 - HJ23;
PPMs(8) = CenterFreqPPM + dPPM - HJ34 + HJ23;
PPMs(9) = CenterFreqPPM + dPPM - HJ34 - HJ23;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);

% --- Executes on button press in Glu_C3D23.
function Glu_C3D23_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C3 D23';
LIdx = 3;
JCIdx = 2;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C3D34.
function Glu_C3D34_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C3 D34';
LIdx = 3;
JCIdx = 4;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C3Q.
function Glu_C3Q_Callback(hObject, eventdata, handles)
QuartetID = 'Glu C3 Q';
LIdx = 3;
JCIdxLow = 2;
JCIdxHigh = 4;
JAHz = handles.GluEstJAHz;
FreqsPPM = handles.GluEstFreqsPPM;
handles.GluFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C4S.
function Glu_C4S_Callback(hObject, eventdata, handles)
SingletID = 'Glu C4 S';
LIdx = 4;
EstFreqsPPM = handles.GluEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.GluEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.GluEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J34 = JA(3,4);
HJ34 = J34/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C4 D34');
PPMs(2) = CenterFreqPPM + HJ34 + dPPM;
PPMs(3) = CenterFreqPPM - HJ34 + dPPM;
J45 = JA(4,5);
HJ45 = J45/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C4 D45');
PPMs(4) = CenterFreqPPM + HJ45 + dPPM;
PPMs(5) = CenterFreqPPM - HJ45 + dPPM;
dPPM = GetIsotopeShift(handles, 'Glu C4 Q');
PPMs(6) = CenterFreqPPM + dPPM + HJ45 + HJ34;
PPMs(7) = CenterFreqPPM + dPPM + HJ45 - HJ34;
PPMs(8) = CenterFreqPPM + dPPM - HJ45 + HJ34;
PPMs(9) = CenterFreqPPM + dPPM - HJ45 - HJ34;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C4_D34.
function Glu_C4_D34_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C4 D34';
LIdx = 4;
JCIdx = 3;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Glu_C4_D45.
function Glu_C4_D45_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C4 D45';
LIdx = 4;
JCIdx = 5;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);

% --- Executes on button press in Glu_C4Q.
function Glu_C4Q_Callback(hObject, eventdata, handles)
QuartetID = 'Glu C4 Q';
LIdx = 4;
JCIdxLow = 3;
JCIdxHigh = 5;
JAHz = handles.GluEstJAHz;
FreqsPPM = handles.GluEstFreqsPPM;
handles.GluFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C5S.
function Glu_C5S_Callback(hObject, eventdata, handles)
SingletID = 'Glu C5 S';
LIdx = 5;
EstFreqsPPM = handles.GluEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.GluEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.GluEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J45 = JA(4,5);
HJ45 = J45/2.0;
dPPM = GetIsotopeShift(handles, 'Glu C5 D45');
PPMs(2) = CenterFreqPPM + HJ45 + dPPM;
PPMs(3) = CenterFreqPPM - HJ45 + dPPM;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Glu_C5D.
function Glu_C5D_Callback(hObject, eventdata, handles)
DoubletID = 'Glu C5 D';
LIdx = 5;
JCIdx = 4;
FreqsPPM = handles.GluEstFreqsPPM;
JAHz = handles.GluEstJAHz;
handles.GluEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C1S.
function Asp_C1S_Callback(hObject, eventdata, handles)
SingletID = 'Asp C1 S';
LIdx = 1;
EstFreqsPPM = handles.AspEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.AspEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.AspEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C1 D12');
PPMs(2) = CenterFreqPPM + HJ12 + dPPM;
PPMs(3) = CenterFreqPPM - HJ12 + dPPM;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C1D.
function Asp_C1D_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C1 D';
LIdx = 1;
JCIdx = 2;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C2S.
function Asp_C2S_Callback(hObject, eventdata, handles)
SingletID = 'Asp C2 S';
LIdx = 2;
EstFreqsPPM = handles.AspEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.AspEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.AspEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J12 = JA(1,2);
HJ12 = J12/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C2 D12');
PPMs(2) = CenterFreqPPM + HJ12 + dPPM;
PPMs(3) = CenterFreqPPM - HJ12 + dPPM;
J23 = JA(2,3);
HJ23 = J23/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C2 D23');
PPMs(4) = CenterFreqPPM + HJ23 + dPPM;
PPMs(5) = CenterFreqPPM - HJ23 + dPPM;
dPPM = GetIsotopeShift(handles, 'Asp C2 Q');
PPMs(6) = CenterFreqPPM + dPPM + HJ12 + HJ23;
PPMs(7) = CenterFreqPPM + dPPM + HJ12 - HJ23;
PPMs(8) = CenterFreqPPM + dPPM - HJ12 + HJ23;
PPMs(9) = CenterFreqPPM + dPPM - HJ12 - HJ23;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C2D12.
function Asp_C2D12_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C2 D12';
LIdx = 2;
JCIdx = 1;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C2D23.
function Asp_C2D23_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C2 D23';
LIdx = 2;
JCIdx = 3;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C2Q.
function Asp_C2Q_Callback(hObject, eventdata, handles)
QuartetID = 'Asp C2 Q';
LIdx = 2;
JCIdxLow = 3;
JCIdxHigh = 1;
JAHz = handles.AspEstJAHz;
FreqsPPM = handles.AspEstFreqsPPM;
handles.AspFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C3S.
function Asp_C3S_Callback(hObject, eventdata, handles)
SingletID = 'Asp C3 S';
LIdx = 3;
EstFreqsPPM = handles.AspEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.AspEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.AspEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J23 = JA(2,3);
HJ23 = J23/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C3 D23');
PPMs(2) = CenterFreqPPM + HJ23 + dPPM;
PPMs(3) = CenterFreqPPM - HJ23 + dPPM;
J34 = JA(3,4);
HJ34 = J34/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C3 D34');
PPMs(4) = CenterFreqPPM + HJ34 + dPPM;
PPMs(5) = CenterFreqPPM - HJ34 + dPPM;
dPPM = GetIsotopeShift(handles, 'Asp C3 Q');
PPMs(6) = CenterFreqPPM + dPPM + HJ23 + HJ34;
PPMs(7) = CenterFreqPPM + dPPM + HJ23 - HJ34;
PPMs(8) = CenterFreqPPM + dPPM - HJ23 + HJ34;
PPMs(9) = CenterFreqPPM + dPPM - HJ23 - HJ34;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(9)-0.5, PPMs(6)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C3D23.
function Asp_C3D23_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C3 D23';
LIdx = 3;
JCIdx = 2;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C3D34.
function Asp_C3D34_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C3 D34';
LIdx = 3;
JCIdx = 4;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in Asp_C3Q.
function Asp_C3Q_Callback(hObject, eventdata, handles)
QuartetID = 'Asp C3 Q';
LIdx = 3;
JCIdxLow = 2;
JCIdxHigh = 4;
JAHz = handles.AspEstJAHz;
FreqsPPM = handles.AspEstFreqsPPM;
handles.AspFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C4S.
function Asp_C4S_Callback(hObject, eventdata, handles)
SingletID = 'Asp C4 S';
LIdx = 4;
EstFreqsPPM = handles.AspEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.AspEstFreqsPPM = EstFreqsPPM;
PPMLow = CenterFreqPPM - DisplayPPMWidth/2.0;
PPMHigh = PPMLow + DisplayPPMWidth;
ax1 = handles.axes1;
clear PPMs;
PPMs(1) = CenterFreqPPM;
JAHz = handles.AspEstJAHz;
Spectrum = handles.Spectrum;
JA = JAHz/Spectrum.ScannerFreqMHz;
J34 = JA(3,4);
HJ34 = J34/2.0;
dPPM = GetIsotopeShift(handles, 'Asp C4 D34');
PPMs(2) = CenterFreqPPM + HJ34 + dPPM;
PPMs(3) = CenterFreqPPM - HJ34 + dPPM;
% Spectrum = FixSpectrumBaseline(Spectrum, PPMs(3)-0.5, PPMs(2)+0.5, 0.1);
% handles.Spectrum = Spectrum;
DisplayReferencedSubSPectrum(Spectrum, ax1, PPMs, PPMLow, PPMHigh);
guidata(hObject, handles);


% --- Executes on button press in Asp_C4D.
function Asp_C4D_Callback(hObject, eventdata, handles)
DoubletID = 'Asp C4 D';
LIdx = 4;
JCIdx = 3;
FreqsPPM = handles.AspEstFreqsPPM;
JAHz = handles.AspEstJAHz;
handles.AspEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C1S.
function bHB_C1S_Callback(hObject, eventdata, handles)
SingletID = 'bHB C1 S';
LIdx = 1;
EstFreqsPPM = handles.bHBEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.bHBEstFreqsPPM = EstFreqsPPM;
guidata(hObject, handles);


% --- Executes on button press in bHB_C1D.
function bHB_C1D_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C1 D12';
LIdx = 1;
JCIdx = 2;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C2S.
function bHB_C2S_Callback(hObject, eventdata, handles)
SingletID = 'bHB C2 S';
LIdx = 2;
EstFreqsPPM = handles.bHBEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.bHBEstFreqsPPM = EstFreqsPPM;
guidata(hObject, handles);


% --- Executes on button press in bHB_C2D12.
function bHB_C2D12_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C2 D12';
LIdx = 2;
JCIdx = 1;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C2D23.
function bHB_C2D23_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C2 D23';
LIdx = 2;
JCIdx = 3;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C2Q.
function bHB_C2Q_Callback(hObject, eventdata, handles)
QuartetID = 'bHB C2 Q';
LIdx = 2;
JCIdxLow = 3;
JCIdxHigh = 1;
JAHz = handles.bHBEstJAHz;
FreqsPPM = handles.bHBEstFreqsPPM;
handles.bHBFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);

% --- Executes on button press in bHB_C3S.
function bHB_C3S_Callback(hObject, eventdata, handles)
SingletID = 'bHB C3 S';
LIdx = 3;
EstFreqsPPM = handles.bHBEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.bHBEstFreqsPPM = EstFreqsPPM;
guidata(hObject, handles);


% --- Executes on button press in bHB_C3D23.
function bHB_C3D23_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C3 D23';
LIdx = 3;
JCIdx = 2;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C3D34.
function bHB_C3D34_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C3 D34';
LIdx = 3;
JCIdx = 4;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);


% --- Executes on button press in bHB_C3Q.
function bHB_C3Q_Callback(hObject, eventdata, handles)
QuartetID = 'bHB C3 Q';
LIdx = 3;
JCIdxLow = 2;
JCIdxHigh = 4;
JAHz = handles.bHBEstJAHz;
FreqsPPM = handles.bHBEstFreqsPPM;
handles.bHBFreqsPPM = SetUsersQuartet(handles, QuartetID, FreqsPPM, ...
                            JAHz, LIdx, JCIdxLow, JCIdxHigh);
guidata(hObject, handles);


% --- Executes on button press in bHB_C4S.
function bHB_C4S_Callback(hObject, eventdata, handles)
SingletID = 'bHB C4 S';
LIdx = 4;
EstFreqsPPM = handles.bHBEstFreqsPPM;
DisplayPPMWidth = handles.SingletDisplayPPMWidth;
EstFreqPPM = EstFreqsPPM(LIdx);
Singlet = GetSingletFromUser(handles, SingletID, EstFreqPPM, DisplayPPMWidth);
CenterFreqPPM = Singlet.CenterFreqPPM;
EstFreqsPPM(LIdx) = CenterFreqPPM;
handles.bHBEstFreqsPPM = EstFreqsPPM;
guidata(hObject, handles);


% --- Executes on button press in bHB_C4D.
function bHB_C4D_Callback(hObject, eventdata, handles)
DoubletID = 'bHB C4 D';
LIdx = 4;
JCIdx = 3;
FreqsPPM = handles.bHBEstFreqsPPM;
JAHz = handles.bHBEstJAHz;
handles.bHBEstFreqsPPM = SetUsersDoublet(handles, DoubletID, FreqsPPM, ...
                            JAHz, LIdx, JCIdx);
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1



function UserInstruct_Callback(hObject, eventdata, handles)
% hObject    handle to UserInstruct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of UserInstruct as text
%        str2double(get(hObject,'String')) returns contents of UserInstruct as a double


% --- Executes during object creation, after setting all properties.
function UserInstruct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to UserInstruct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in radiobutton58.
function radiobutton58_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton58 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton58


% --- Executes on button press in radiobutton59.
function radiobutton59_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton59 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton59



function MinFitR2Edit_Callback(hObject, eventdata, handles)
% hObject    handle to MinFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MinFitR2Edit as text
%        str2double(get(hObject,'String')) returns contents of MinFitR2Edit as a double
MinFitR2 = str2double(get(hObject,'String'));
% handles.MinFitR2 = MinFitR2;
MinFitR2Edit = handles.MinFitR2Edit;
MinFitR2Edit.String = num2str(MinFitR2, '% 5.2f');
handles.MinFitR2Edit = MinFitR2Edit;


% --- Executes during object creation, after setting all properties.
function MinFitR2Edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MinFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to MinFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MinFitR2Edit as text
%        str2double(get(hObject,'String')) returns contents of MinFitR2Edit as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MinFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MaxFitR2Edit_Callback(hObject, eventdata, handles)
% hObject    handle to MaxFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MaxFitR2Edit as text
%        str2double(get(hObject,'String')) returns contents of MaxFitR2Edit as a double
MaxFitR2 = str2double(get(hObject,'String'));
% handles.MaxFitR2 = MaxFitR2;
MaxFitR2Edit = handles.MaxFitR2Edit;
MaxFitR2Edit.String = num2str(MaxFitR2, '% 5.2f');
handles.MaxFitR2Edit = MaxFitR2Edit;

% --- Executes during object creation, after setting all properties.
function MaxFitR2Edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MaxFitR2Edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
