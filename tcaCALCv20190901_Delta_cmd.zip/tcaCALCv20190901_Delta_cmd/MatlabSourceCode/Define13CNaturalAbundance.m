function NaturalAbundance = Define13CNaturalAbundance()
NaturalAbundance = 0.0107;

end

