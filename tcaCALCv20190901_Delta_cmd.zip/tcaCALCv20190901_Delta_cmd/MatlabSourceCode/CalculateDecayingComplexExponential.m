function CDE = CalculateDecayingComplexExponential(SampleTimesSec, R2, ...
                        FreqHz, Amplitude, PhaseDegrees, ImagSign)
% Validated JRA 10/6/2016
% test parameters
% ImagSign = '-';
% FreqHz = 7;     
% PhaseDegrees = 90.0;
% Amplitude = 10.0;
% R2 = 1.0;

Rate = 360.0*FreqHz;
Angles = SampleTimesSec * Rate;
Angles = Angles + PhaseDegrees;
rS = cosd(Angles);
iS = sind(Angles);
R2t = -SampleTimesSec * R2;
DF = exp(R2t);
rS = times(rS, DF);
iS = times(iS, DF);
if strcmp(ImagSign,'-')
     iS = -iS;
end
CDE = complex(rS,iS);
CDE = CDE*Amplitude;

% test plots
% X = SampleTimesSec;
% Y = CDE;
% maxX = 3.0
% Y = Y(X < maxX);
% X = X(X < maxX);
% 
% ReY = real(Y);
% ImY = imag(Y);
% 
% plot(X,ReY, 'g-', X, ImY, 'r-');
% Dummy = 1;
end
    
    
