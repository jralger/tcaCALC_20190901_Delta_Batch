function AcA_ACS= AcetylCoASynthetase(FAs, AcA, m)
AcA_ACS = AcA;
AcA_ACS(m, :) = FAs(m, :);
end

