function [ooooo, xoooo, oxooo, xxooo, ...
          ooxoo, xoxoo, oxxoo, xxxoo, ...
          oooxo, xooxo, oxoxo, xxoxo, ...
          ooxxo, xoxxo, oxxxo, xxxxo, ...
          oooox, xooox, oxoox, xxoox, ...
          ooxox, xoxox, oxxox, xxxox, ...
          oooxx, xooxx, oxoxx, xxoxx, ...
          ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices()

% This function defines the label indices for a five carbon molecule
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg xxooo means a five carbon moelcule labelled with C13 at carbons 1 and
% 2
% there are no inputs
% returns the numerical values of indices for all possible isotopomers
      
      
ooooo = 1;
xoooo = 2;
oxooo = 3;
xxooo = 4;

ooxoo = 5;
xoxoo = 6;
oxxoo = 7;
xxxoo = 8;

oooxo = 9;
xooxo = 10;
oxoxo = 11;
xxoxo = 12;

ooxxo = 13;
xoxxo = 14;
oxxxo = 15;
xxxxo = 16;

oooox = 17;
xooox = 18;
oxoox = 19;
xxoox = 20;

ooxox = 21;
xoxox = 22;
oxxox = 23;
xxxox = 24;

oooxx = 25;
xooxx = 26;
oxoxx = 27;
xxoxx = 28;

ooxxx = 29;
xoxxx = 30;
oxxxx = 31;
xxxxx = 32;

end

