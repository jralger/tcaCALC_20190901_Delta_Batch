function [oo, xo, ox, xx] = DefineTwoCarbonLabelIndices()

% This function defines the label indices for a two carbon molecule
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg xo means a two carbon moelcule labelled with C13 at carbons 1
% there are no inputs
% returns the numerical values of indices for all possible isotopomers  

oo = 1;
xo = 2;
ox = 3;
xx = 4;


end

