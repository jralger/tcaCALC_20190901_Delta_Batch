function PlotGDAModelsResults(MMs, WDN)

MMs = MetablicModelsDiet(MMs);
FN = 'C:\Users\Jeffry R Alger\Desktop\GetPlotWorking\MMs.mat';
save(FN, 'MMs');
% load(FN, 'MMs');

MS = 8;
FS = 14;
SubplotRows = 7;
SubplotCols = 2;

AICs = GetValuesFromMetabolicModels(MMs, 'AICc');

nMMs = size(MMs, 2);
[AICs, idx] = sort(AICs);
MMs(1, :) = MMs(1, idx);

AICs = GetValuesFromMetabolicModels(MMs, 'AICc');
BEVs = GetValuesFromMetabolicModels(MMs, 'BestEV');
LnRess = log(BEVs);
ADps = GetValuesFromMetabolicModels(MMs, 'ADp');

% BestLnResMM = MMs(LnRess == min(LnRess));
% nBestLnResMM = size(BestLnResMM, 2);
% if nBestLnResMM > 1
%     BestLnResMM = BestLnResMM(1,1);
% end
    
for i = 1:nMMs
    MM = MMs(1, i);
    XIDs = MM.XIDs;
    T = '';
    Models(1, i) = {[T , MM.ExptID,]};
end

MM = MMs(1, 1);
GDA = MM.GDA;
M = GDA(1);
SID = M.StudyID;
PT =  M.StudyID;
T = strsplit(PT, '_');
nT = size(T,2);
if nT > 1
    PT = char(T(1));
    for i = 2:nT
        PT = [PT, ' ', char(T(i))];
    end
end

figure('Position', [50, 50, 1024, 1024], 'Color', 'w');

% TB = annotation('textbox');
% TB.FontSize = FS;
% TB.Position = [0.05, 0.05, 0.45, 0.45];
% TB.LineStyle = 'none';
% 
% TB.String = {[PT,  ''], ...
%              ['AIC Best Model: ', char(Models(1,1))], ...
%              ['AIC Best Model Rates', ' '], ...
%              ['    PDH: ', num2str(MM.PDH)], ...
%              ['    YPC: ', num2str(MM.YPC)], ...
%              ['    PK: ', num2str(MM.PK)], ...
%              ['    Ys: ', num2str(MM.Ys)]};

% TB2 = annotation('textbox');
% TB2.FontSize = FS;
% TB2.Position = [0.05, 0.55, 0.45, 0.45];
% TB2.LineStyle = 'none';
% TB2.String = {[PT,  ''], ...
%              ['Ln(Residual) Best Model: ', BestLnResMM.ExptID], ...
%              ['Ln(Residual) Best Model Rates', ' '], ...
%              ['    PDH: ', num2str(BestLnResMM.PDH)], ...
%              ['    YPC: ', num2str(BestLnResMM.YPC)], ...
%              ['    PK: ', num2str(BestLnResMM.PK)], ...
%              ['    Ys: ', num2str(BestLnResMM.Ys)]};

% subplot(SubplotRows,SubplotCols,1);
% MM = MMs(1,1);
% BestAICModelpng = [MM.ExptID, '.png'];
% imshow(BestAICModelpng);
% title('Best AIC Model', 'fontsize', FS);
% axis off;

% subplot(SubplotRows,SubplotCols,3);
% MM = MMs(1,1);
% BestLnResModelpng = [BestLnResMM.ExptID, '.png'];
% imshow(BestLnResModelpng);
% title('Best Ln(Residual) Model', 'fontsize', FS);
% axis off;


for i =1:nMMs
    X(i) = i;
end

PIDs = {'AICc', 'BestEV', 'ADp'};
YLA =  {'AICc', 'Ln(Resid)', 'ADp'};
CA =   {'g',    'b',         'm'};
nPIDs = size(PIDs, 2);

PN = 1;

for i = 1:nPIDs
    PID = char(PIDs(1,i));
    YL = char(YLA(1,i));
    C = char(CA(1,i));
    ax = subplot(SubplotRows,SubplotCols,PN);
    Y = GetValuesFromMetabolicModels(MMs, PID);
    if strcmp(PID, 'BestEV')
        Y = log(Y);
    end
    S = [C, 'o'];
    plot(ax, X, Y, S,  'MarkerFaceColor', C, 'MarkerSize', MS);
    ax = SetAxProps(ax, X, FS);
    ax.YLabel.String = YL;
    if PN == 1
        title(PT);
    end
    axs(1,1) = ax;
    PN = PN + SubplotCols;
end

M = 4;
IDs = {'PDH', 'YPC', 'PK', 'Ys'};
CA =  {'g',   'b',   'r',  'm'};
nIDs = size(IDs, 2);
for i = 1:nIDs
    ID = char(IDs(1,i));
    C = char(CA(1,i));
    [XP, YP, EP, N, XPZ, YPZ, Z] = BuildPlotParams(MMs, ID);
    if N > 1
        subplot(SubplotRows,SubplotCols,PN);
        ax = RatePlot(X, Models, XP, YP, EP, C, MS, FS, ID);
    end
    if Z > 1
        MZ = [C,'o'];
        hold;
        plot(XPZ, YPZ, MZ, 'MarkerSize', MS, 'linewidth', 2);
    end
    axs(1,M) = ax;
    M = M + 1;
    PN = PN + SubplotCols;
end

% linkaxes(axs,'x');
ax = gca;
ax.XTickLabel = Models;
ax.XAxisLocation = 'bottom';
ax.XTickLabelRotation = -45;
ax.XLabel.String = 'ModelID';
ax.XLabel.FontSize = FS;
ax.XTickLabelMode =  'manual';

FN = [WDN, SID, '_ModelsResultsRates', '.png'];
saveas(gcf, FN);

FittedSubstrates = {};
N = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    nXIDs = size(XIDs,2);
    for j = 1:nXIDs
        XID = char(XIDs(1, j));
        if contains(XID, ' ')
            if contains(XID, 'x')
                FittedSubstrates(1, N) = {XID};
                N = N + 1;
            end
        end
    end
end




FittedSubstrates = unique(FittedSubstrates);
nFS = size(FittedSubstrates, 1);

if nFS > 0
    figure('Position', [70, 70, 1600, 1000], 'Color', 'w');
    CA = {'b', 'g', 'r', 'm'};
    for i = 1:nFS
        Sub = FittedSubstrates(1,i);
        [XP, YP, EP, N] = BuildPlotParamsSubstrates(MMs, Sub);
        if N > 1
            subplot(2,2,i);
            C = char(CA(1,i));
            RatePlot(PT, X, Models, XP, YP, EP, C, MS, FS, Sub);
        end
    end

    FN = [WDN, SID, '_ModelsResultsSubstrates', '.png'];
    saveas(gcf, FN);
end

end
    

function ax = RatePlot(X, Models, XP, YP, EP, C, MS, FS, ID)
M = [C, 'o'];
YL = [ID, ' +/- STD'];
errorbar(XP, YP, EP, M,  'MarkerFaceColor', C, 'MarkerSize', MS, 'linewidth', 2);
YT = YP + EP;
yr = [0, 1.1*max(YT)];
if yr(2) > 10.0
    yr(2) = 10.0;
end
ax = gca;
ax = SetAxProps(ax, X, FS);
ax.YLabel.String = YL;
ax.YLim = yr;
end
    

function [XP, YP, EP, N, XPZ, YPZ, M] = BuildPlotParams(MMs, ID)
nMMs = size(MMs,2);
N = 1;
M = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    STD = MM.XSTDCovar;
    if any(strcmp(XIDs, ID))
        XP(N) = i;
        YP(N) = MM.(ID);
        EP(N) = STD(strcmp(XIDs, ID));
        N = N + 1;
    else
        XPZ(M) = i;
        YPZ(M) = MM.(ID);
        M = M + 1;
    end
end
end



function [XP, YP, EP, N] = BuildPlotParamsSubstrates(MMs, ID)
XP = [];
YP = [];
EP = [];
nMMs = size(MMs,2);
N = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    STD = MM.XSTDCovar;
    if any(strcmp(XIDs, ID))
        XID = char(XIDs(strcmp(XIDs, ID)));
        XP(N) = i;
        YP(N) = GetIsotopomerFromStruct(MM, XID);
        EP(N) = STD(strcmp(XIDs, ID));
        N = N + 1;
    end
end
end

function VA = GetValuesFromMetabolicModels(MMs, VID)
nMMs = size(MMs, 2);
VA = zeros(1, nMMs);
for i = 1:nMMs
    MM = MMs(1, i);
    VA(1, i) = MM.(VID);
end
end



function ax = SetAxProps(ax, X, FS)
ax.FontName = 'Helvetica';
ax.FontSize =  FS;
ax.FontWeight = 'normal';
ax.XTick = X;
ax.XLim = [min(X)-1, max(X)+1];
ax.XTickLabelMode =  'manual';
ax.YLabel.FontSize = FS;
end


function NMMs = MetablicModelsDiet(MMs)

nMMs = size(MMs, 2);

for i = 1:nMMs
    MM = MMs(1,i);
    MM = rmfield(MM, 'AlaMultiplets');
    MM = rmfield(MM, 'AspMultiplets');
    MM = rmfield(MM, 'GlcMultiplets');
    MM = rmfield(MM, 'GluMultiplets');
    MM = rmfield(MM, 'MAGMultiplets');
    MM = rmfield(MM, 'bHBMultiplets');
    NMMs(1,i) = MM;
end

end


% XID = char(XIDs(1,j));
%          U = strsplit(XID, ' ');
%          nU = size(U, 2);
%          if nU == 1
%             txt = [txt, num2str(MM.(XID)), ','];
%          end
%          if nU == 2
%             V = GetIsotopomerFromStruct(MM, XID);
%             txt = [txt, num2str(V), ','];
%          end



%     Q = strcmp(XIDs, 'PDH');
%     if any(Q)
%         T = [T, ' 1'];
%     else
%         T = [T, ' 0'];
%     end
%     Q = strcmp(XIDs, 'YPC');
%     if any(Q)
%         T = [T, ' 1'];
%     else
%         T = [T, ' 0'];
%     end
%     Q = strcmp(XIDs, 'PK');
%     if any(Q)
%         T = [T, ' 1'];
%     else
%         T = [T, ' 0'];
%     end
%     Q = strcmp(XIDs, 'Ys');
%     if any(Q)
%         T = [T, ' 1'];
%     else
%         T = [T, ' 0'];
%     end
%     T = [T, ' '];
