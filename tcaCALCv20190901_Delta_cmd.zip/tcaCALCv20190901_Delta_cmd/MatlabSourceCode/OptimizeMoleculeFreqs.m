function RMolecule = OptimizeMoleculeFreqs(Molecule, Spectrum, ...
                       TestFreqsPPMRange, TestFreqsPPMInc, ...
                       RCalcPPMRange)
nTests = round(TestFreqsPPMRange/TestFreqsPPMInc);
StartValue = -TestFreqsPPMRange/2.0;
ValueInc = TestFreqsPPMInc;
TestValues = zeros(nTests, 1);
for i = 1:nTests
    TestValues(i) = StartValue + ((i-1)*ValueInc);
end
TestFreqs = TestValues;

FreqsPPM = Molecule.FreqsPPM;
JAPPM = Molecule.JAPPM;
LabelPattern = Molecule.LabelPattern;
Signals = Molecule.Signals;
% nSignals = size(Signals);
Signal = Signals(1);
ShapeParams = Signal.ShapeParams;
GlobalR2 = ShapeParams(1);
sf = str2num(Molecule.ScannerFreqMHz);
CenterPPM = str2num(Molecule.CenterPPM);
SampleTimesSec = Molecule.SampleTimesSec;
CenterPPM = str2num(Molecule.CenterPPM);
MolConc = Molecule.Conc;

TestFreqsPPM = FreqsPPM;
TestFreqsPPM(1, 1) = FreqsPPM(1, 1) + TestFreqs(1, 1);
BestTestMolecule = BuildIsotopMolecule(LabelPattern, TestFreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
BestR = GetResidual(BestTestMolecule, Spectrum, RCalcPPMRange);

nFreqs = size(FreqsPPM, 2);
nTestFreqs = size(TestFreqs,1);
for i = 1:nFreqs
    for j = 1:nTestFreqs
        TestFreqsPPM = FreqsPPM;
        TestFreqsPPM(1, i) = FreqsPPM(1, i) + TestFreqs(j,1);
        TestMolecule = BuildIsotopMolecule(LabelPattern, TestFreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);  
        R = GetResidual(TestMolecule, Spectrum, RCalcPPMRange);
        if R < BestR
            BestTestMolecule = TestMolecule;
            BestR = R;
        end
    end
end

RMolecule = BestTestMolecule;
RMolecule.PlotCenters = RMolecule.FreqsPPM;
end

