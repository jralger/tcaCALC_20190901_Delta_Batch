function [AcA_PDH, CO2_PDH] = PyruvateDehydrogenase(Pyr, AcA, CO2, m)

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();                                
[o, x] = DefineOneCarbonLabelIndices();

AcA_PDH = AcA;
AcA_PDH(m, oo) = Pyr(m, ooo) + Pyr(m, xoo);
AcA_PDH(m, xo) = Pyr(m, oxo) + Pyr(m, xxo);
AcA_PDH(m, ox) = Pyr(m, oox) + Pyr(m, xox);
AcA_PDH(m, xx) = Pyr(m, oxx) + Pyr(m, xxx);

CO2_PDH = CO2;
CO2_PDH(m, o) = Pyr(m, ooo) + ...
                Pyr(m, oxo) + ...
                Pyr(m, oox) + ...
                Pyr(m, oxx);
CO2_PDH(m, x) = Pyr(m, xoo) + ...
                Pyr(m, xxo) + ...
                Pyr(m, xox) + ...
                Pyr(m, xxx);

end

