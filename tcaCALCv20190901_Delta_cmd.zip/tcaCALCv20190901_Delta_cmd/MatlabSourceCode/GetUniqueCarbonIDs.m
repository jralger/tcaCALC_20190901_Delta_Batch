function uIDs = GetUniqueCarbonIDs(Molecules)
nMols = size(Molecules, 1);
for i = 1:nMols
    Molecule = Molecules(i);
    ID = Molecule.ID;
    ID = strsplit(ID);
    ID = [char(ID(1)), ' ', char(ID(2))];
    ID = cellstr(ID);
    if i == 1
        IDs = [ID];
    end
    if i > 1
        IDs = [IDs, ID];
    end
end
uIDs = unique(IDs);
end

