function dPPM = GetIsotopeShift(handles, ID)
dPPM = 0.0;
IsoShifts = handles.IsoShifts;
n = size(IsoShifts, 1);
for i = 1:n
    IsoShift = IsoShifts(i,1);
    TID = IsoShift.ID;
    TdPPM = IsoShift.dPPM;
    if strmatch(TID, ID)
        dPPM = TdPPM;
    end
end


end

