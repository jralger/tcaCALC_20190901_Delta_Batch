function bHB = Ketogenesis(AcA, bHB, m)
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                         DefineFourCarbonLabelIndices();
                                     
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

bHB(m, oooo) = AcA(m, oo)*AcA(m, oo);
bHB(m, xooo) = AcA(m, xo)*AcA(m, oo);
bHB(m, oxoo) = AcA(m, ox)*AcA(m, oo);
bHB(m, xxoo) = AcA(m, xx)*AcA(m, oo);

bHB(m, ooxo) = AcA(m, oo)*AcA(m, xo);
bHB(m, xoxo) = AcA(m, xo)*AcA(m, xo);
bHB(m, oxxo) = AcA(m, ox)*AcA(m, xo);
bHB(m, xxxo) = AcA(m, xx)*AcA(m, xo);

bHB(m, ooox) = AcA(m, oo)*AcA(m, ox);
bHB(m, xoox) = AcA(m, xo)*AcA(m, ox);
bHB(m, oxox) = AcA(m, ox)*AcA(m, ox);
bHB(m, xxox) = AcA(m, xx)*AcA(m, ox);

bHB(m, ooxx) = AcA(m, oo)*AcA(m, xx);
bHB(m, xoxx) = AcA(m, xo)*AcA(m, xx);
bHB(m, oxxx) = AcA(m, ox)*AcA(m, xx);
bHB(m, xxxx) = AcA(m, xx)*AcA(m, xx);

end

