function [handles, Molecule] = BuildSingletMolecule(handles, Singlet, LabelPattern, EstFreqsPPM, LIdx)
nC = size(LabelPattern, 2);
JAPPM = zeros(nC);
Spectrum = handles.Spectrum;
SF = Spectrum.ScannerFreqMHz;
SampleTimesSec = Spectrum.SampleTimesSec;
EstFreqsPPM(LIdx) = Singlet.CenterFreqPPM;
CenterPPM = Spectrum.CenterPPM;
GlobalR2 = handles.GlobalR2;
DefaultMolConc = handles.DefaultMolConc;
Molecule = BuildIsotopMolecule(LabelPattern, EstFreqsPPM, ...
                      JAPPM, DefaultMolConc, GlobalR2, SF, ...
                      SampleTimesSec, CenterPPM);
Molecule.FreqsPPM(LIdx) = Singlet.CenterFreqPPM;
Molecule.ID = Singlet.ID;
Molecule.PlotCenters = Singlet.CenterFreqPPM;
handles = AddMolecule(handles, Molecule);
end

