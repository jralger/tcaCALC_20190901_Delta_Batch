function DisplaySaveMoleculeFits(BMPFN, Spectrum, Molecules);
% fails when only singlets are fit
nM = size( Molecules,1);
PPMTable = Spectrum.PPMTable;

FN = [BMPFN, '\', 'AllMoleculesFitted.mat'];
save(FN, 'Molecules'); 
FN = [BMPFN, '\', 'Spectrum.mat'];
save(FN, 'Spectrum'); 


for i = 1:nM
    Molecule = Molecules(i);
    JAPPM = Molecule.JAPPM;
    maxJAPPM = max(JAPPM);
    maxJAPPM = max(maxJAPPM);
    if i == 1
        maxAllJAPPM = maxJAPPM;
    end
    if i > 1
        if maxJAPPM > maxAllJAPPM
            maxAllJAPPM = maxJAPPM;
        end
    end
end
SingletCalcRangePPM = 3.0*maxAllJAPPM;
    
for i = 1:nM
    Molecule = Molecules(i);
    ID = Molecule.ID;
    ModelSpectrum = Molecule.ConcWtdSpectrum;
    JAPPM = Molecule.JAPPM;
    maxJAPPM = max(JAPPM);
    maxJAPPM = max(maxJAPPM);
    CalcPPMRangeLow = -3.0*maxJAPPM/2.0;
    CalcPPMRangeHigh = 3.0*maxJAPPM/2.0;
    if maxJAPPM == 0.0
       CalcPPMRangeLow = -SingletCalcRangePPM/2.0;
       CalcPPMRangeHigh = SingletCalcRangePPM/2.0;
    end
    FreqPPM = Molecule.PlotCenters;
    PPMLow = FreqPPM + CalcPPMRangeLow;
    PPMHigh = FreqPPM + CalcPPMRangeHigh;
    B = ['  Best Fit Raw Intensity: ', num2str(Molecule.Conc)];
    D = ['  Best Fit Fractional Intensity: ', num2str(Molecule.FractionalConc)];
    E = ['  Best Fit Fractional Integral: ', num2str(Molecule.FractionalIntegral)];
    C = ['  Multiplet Center PPM: ', num2str(Molecule.PlotCenters)];
    AnnTxt = {ID};
    AnnTxt{2} = C;
    AnnTxt{3} = B;
    AnnTxt{4} = D;
    AnnTxt{5} = E;
    n = 6;
    sf = str2num(Molecule.ScannerFreqMHz);
    JAHz = JAPPM*sf;
    nJ = size(JAHz,1);
    for l = 1:nJ
        for m = 1:nJ
            if l < m
               if JAHz(l,m) ~= 0.0
                  Q = ['  JAHz(', num2str(l), ', ', num2str(m), '): ',num2str(JAHz(l,m))];
                  AnnTxt{n} = Q;
                  n = n + 1;
               end
            end
       end
   end
   Signals = Molecule.Signals;
   Signal = Signals(1);
   ShapeParams = Signal.ShapeParams;
   R2 = ShapeParams(1);
   Q = ['  LorentzR2 (sec-1): ', num2str(R2)]; 
   AnnTxt{n} = Q;
   n = n + 1;
   DisplaySpectrumAndModelOverPPMRange(Spectrum, ModelSpectrum, ...
           PPMLow, PPMHigh, ID, AnnTxt, 0);
   FN = [BMPFN, '\', ID, '.png'];
   saveas(gcf,FN);
   Molecules(i) = Molecule;
   close;        
end   
end

