function Molecules = SimulateGlcSpectra(Molecules, V)

[oooooo, xooooo, oxoooo, xxoooo, ...
 ooxooo, xoxooo, oxxooo, xxxooo, ...
 oooxoo, xooxoo, oxoxoo, xxoxoo, ...
 ooxxoo, xoxxoo, oxxxoo, xxxxoo, ...
 ooooxo, xoooxo, oxooxo, xxooxo, ...
 ooxoxo, xoxoxo, oxxoxo, xxxoxo, ...
 oooxxo, xooxxo, oxoxxo, xxoxxo, ...
 ooxxxo, xoxxxo, oxxxxo, xxxxxo, ...
 ooooox, xoooox, oxooox, xxooox, ...
 ooxoox, xoxoox, oxxoox, xxxoox, ...
 oooxox, xooxox, oxoxox, xxoxox, ...
 ooxxox, xoxxox, oxxxox, xxxxox, ...
 ooooxx, xoooxx, oxooxx, xxooxx, ...
 ooxoxx, xoxoxx, oxxoxx, xxxoxx, ...
 oooxxx, xooxxx, oxoxxx, xxoxxx, ...
 ooxxxx, xoxxxx, oxxxxx, xxxxxx] ...
                          = DefineSixCarbonLabelIndices();

nMols = size(Molecules, 2);
% Mol = Molecules(1, 1);
% for i = 1:nMols
%     Mol = Molecules(1, i);
%     ID = Mol.ID
% end

FE = GetFractionalEnrichment(V);

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    
    if strcmp(ID, 'Glc C1 S')
      Conc = V(xooooo) + V(xoxooo) + V(xooxoo) + V(xoxxoo) + ...
             V(xoooxo) + V(xoxoxo) + V(xooxxo) + V(xoxxxo) + ...
             V(xoooox) + V(xoxoox) + V(xooxox) + V(xoxxox) + ...
             V(xoooxx) + V(xoxoxx) + V(xooxxx) + V(xoxxxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C1 D')
      Conc = V(xxoooo) + V(xxxooo) + V(xxoxoo) + V(xxxxoo) + ...
             V(xxooxo) + V(xxxoxo) + V(xxoxxo) + V(xxxxxo) + ...
             V(xxooox) + V(xxxoox) + V(xxoxox) + V(xxxxox) + ...
             V(xxooxx) + V(xxxoxx) + V(xxoxxx) + V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C2 S')
      Conc = V(oxoooo) + V(oxoxoo) + V(oxooxo) + V(oxoxxo) + ...
             V(oxooox) + V(oxoxox) + V(oxooxx) + V(oxoxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C2 D12')
      Conc = V(xxoooo) + V(xxoxoo) + V(xxooxo) + V(xxoxxo) + ...
             V(xxooox) + V(xxoxox) + V(xxooxx) + V(xxoxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C2 D23')
      Conc = V(oxxooo) +  V(oxxxoo) +  V(oxxoxo) +  V(oxxxxo) + ...
             V(oxxoox) +  V(oxxxox) +  V(oxxoxx) +  V(oxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C2 Q')
      Conc = V(xxxooo) + V(xxxxoo) + V(xxxoxo) + V(xxxxxo) + ...
             V(xxxoox) + V(xxxxox) + V(xxxoxx) + V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C3 S')
      Conc = V(ooxooo) + V(xoxooo) + V(ooxoxo) + V(xoxoxo) + ...
             V(ooxoox) + V(xoxoox) + V(ooxoxx) + V(xoxoxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C3 D')
      Conc =  V(oxxooo) + V(xxxooo) + V(oxxoxo) + V(xxxoxo) + ...
              V(oxxoox) + V(xxxoox) + V(oxxoxx) + V(xxxoxx) + ...
              V(ooxxoo) + V(xoxxoo) + V(ooxxxo) + V(xoxxxo) + ...
              V(ooxxox) + V(xoxxox) + V(ooxxxx) + V(xoxxxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C3 T')
      Conc = V(oxxxoo) +  V(xxxxoo) +  V(oxxxxo) +  V(xxxxxo) + ...
             V(oxxxox) +  V(xxxxox) +  V(oxxxxx) +  V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C4 S')
      Conc = V(oooxoo) +  V(xooxoo) +  V(oxoxoo) +  V(xxoxoo) + ...
             V(oooxox) +  V(xooxox) +  V(oxoxox) +  V(xxoxox);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C4 D')
      Conc = V(ooxxoo) + V(xoxxoo) + V(oxxxoo) + V(xxxxoo) + ...
             V(ooxxox) + V(xoxxox) + V(oxxxox) + V(xxxxox) + ...
             V(oooxxo) + V(xooxxo) + V(oxoxxo) + V(xxoxxo) + ...
             V(oooxxx) + V(xooxxx) + V(oxoxxx) + V(xxoxxx);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C4 T')
      Conc = V(ooxxxo) + V(xoxxxo) + V(oxxxxo) + V(xxxxxo) + ...
             V(ooxxxx) + V(xoxxxx) + V(oxxxxx) + V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C5 S')
      Conc = V(ooooxo) + V(xoooxo) + V(oxooxo) + V(xxooxo) + ...
             V(ooxoxo) + V(xoxoxo) + V(oxxoxo) + V(xxxoxo);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C5 D45')
      Conc = V(oooxxo) + V(xooxxo) + V(oxoxxo) + V(xxoxxo) + ...
             V(ooxxxo) + V(xoxxxo) + V(oxxxxo) + V(xxxxxo);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C5 D56')
      Conc = V(ooooxx) + V(xoooxx) + V(oxooxx) + V(xxooxx) + ...
             V(ooxoxx) + V(xoxoxx) + V(oxxoxx) + V(xxxoxx);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C5 Q')
      Conc = V(oooxxx) + V(xooxxx) + V(oxoxxx) + V(xxoxxx) + ...
             V(ooxxxx) + V(xoxxxx) + V(oxxxxx) + V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C6 S')
      Conc = V(ooooox) + V(xoooox) + V(oxooox) + V(xxooox) + ...
             V(ooxoox) + V(xoxoox) + V(oxxoox) + V(xxxoox) + ...
             V(oooxox) + V(xooxox) + V(oxoxox) + V(xxoxox) + ...
             V(ooxxox) + V(xoxxox) + V(oxxxox) + V(xxxxox);
      Mol.Conc = Conc;
      TotConc = FE(6);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glc C6 D')
      Conc = V(ooooxx) + V(xoooxx) + V(oxooxx) + V(xxooxx) + ...
             V(ooxoxx) + V(xoxoxx) + V(oxxoxx) + V(xxxoxx) + ...
             V(oooxxx) + V(xooxxx) + V(oxoxxx) + V(xxoxxx) + ...
             V(ooxxxx) + V(xoxxxx) + V(oxxxxx) + V(xxxxxx);
      Mol.Conc = Conc;
      TotConc = FE(6);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
end

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if contains(ID, 'Glc')
        NS = Mol.NormSpectrum;
        FD = NS.FreqDomainData;
        Conc = Mol.Conc;
        FD = FD*Conc;
        CWS = Mol.ConcWtdSpectrum;
        CWS.FreqDomainData = FD;
        Mol.ConcWtdSpectrum = CWS;
        Molecules(1, i) = Mol;
    end
end

% for i = 1:nMols
%     Mol = Molecules(1, i);
%     Conc = Mol.Conc
% end

end

