function ax = DisplayReferencedSubSPectrum(Spectrum, ax, FreqsPPM, PPMLow, PPMHigh)
CS = Spectrum.FreqDomainData;
Y = real(CS);
X = Spectrum.PPMTable;
Y = Y(X >= PPMLow & X <= PPMHigh);
X = X(X >= PPMLow & X <= PPMHigh);
MinY = min(Y);
MaxY = max(Y);

Z = X*0.0;
plot(X, Y, 'ro-', 'DisplayName','Measured Real Intensity');
hold on;
plot(X, Z, 'k--', 'DisplayName','Zero');
nFreqs = size(FreqsPPM, 2);
ppm = FreqsPPM(1);
XR = [ppm, ppm];
D = abs(X - ppm);
MinD = min(D);
MaxY = 0.90*Y(D == MinD);
MinY = 0;
YR = [MinY, MaxY];
plot(XR, YR, 'b-', 'LineWidth', 2, 'DisplayName','Singlet');
if nFreqs > 1
    for i = 2:3
        ppm = FreqsPPM(i);
        XR = [ppm, ppm];
        D = abs(X - ppm);
        MinD = min(D);
        MaxY = 0.90*Y(D == MinD);
        MinY = 0;
        YR = [MinY, MaxY];
        plot(XR, YR, 'g-', 'LineWidth', 4, 'DisplayName','Doublet');
    end
end
if nFreqs > 3
    for i = 4:5
        ppm = FreqsPPM(i);
        XR = [ppm, ppm];
        D = abs(X - ppm);
        MinD = min(D);
        MaxY = 0.90*Y(D == MinD);
        MinY = 0;
        YR = [MinY, MaxY];
        plot(XR, YR, 'm-', 'LineWidth', 4, 'DisplayName','Doublet');
    end
end
if nFreqs > 5
    for i = 6:9
        ppm = FreqsPPM(i);
        XR = [ppm, ppm];
        D = abs(X - ppm);
        MinD = min(D);
        MaxY = 0.90*Y(D == MinD);
        MinY = 0;
        YR = [MinY, MaxY];
        plot(XR, YR, 'c-', 'LineWidth', 6, 'DisplayName','Triplet/Quartet');
    end
end
ax.XLim = [PPMLow PPMHigh];    
ax.XMinorTick = 'on';       
ax.YAxis.Visible = 'off';
ax.XDir = 'reverse';
ax.Visible = 'on';
ax.XLabel.String = 'PPM';
legend('show');
hold off;

end

