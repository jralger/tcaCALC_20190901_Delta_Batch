function BestFitMolecules = FitMultipletSetConcs(Spectrum, ... 
                               Molecules, MinPPMWidth)
nMols = size(Molecules, 1);
MinPC = 6.023e23;
MaxPC = -6.023e23;
MaxJPPM = 0.0;
PPMRange = MinPPMWidth;

% for i = 1:nMols
%     Molecule = Molecules(i);
%     MolID = Molecule.ID;
%     Signals = Molecule.Signals;
%     Signal = Signals(1);
%     ShapeParams = Signal.ShapeParams;
%     R2 = ShapeParams(1);
%     txt = [MolID, '  R2: ', num2str(R2)];
%     disp(txt);
% end
% txt = ['    '];
% disp(txt);
% disp(txt);
% disp(txt);

for i = 1:nMols
    Molecule = Molecules(i);
    T = max(Molecule.JAPPM);
    if T > PPMRange
        PPMRange = T;
    end
    PCs = Molecule.PlotCenters;
    T = min(PCs);
    if T < MinPC
        MinPC = T;
    end
    T = max(PCs);
    if T > MaxPC
        MaxPC = T;
    end
end
PPMLow = MinPC - PPMRange;
PPMHigh = MaxPC + PPMRange;

Concs = zeros(nMols, 1);
for i = 1:nMols
    Molecule = Molecules(i);
    Concs(i)  = Molecule.Conc;
end
    
ppmtable = Spectrum.PPMTable;
tppmtable = ppmtable(ppmtable >= PPMLow & ppmtable <= PPMHigh);
nppm = size(tppmtable, 1);
NFDs = zeros(nppm, nMols);
for i = 1:nMols
    Molecule = Molecules(i);
    NS = Molecule.NormSpectrum;
    NFD = NS.FreqDomainData;
    NFD = NFD(ppmtable >= PPMLow & ppmtable <= PPMHigh);
    NFDs(:,i) = NFD;
end

MeasuredFD = Spectrum.FreqDomainData;
MeasuredFD = MeasuredFD(ppmtable >= PPMLow & ppmtable <= PPMHigh);
ppmtable = ppmtable(ppmtable >= PPMLow & ppmtable <= PPMHigh);

model = @FitConcsFunc;
BestFitConcs = fminsearch(model, Concs);
BestFitConcs(BestFitConcs < 0.0) = 0.0;

BestFitMolecules = Molecules;
% note that somewhere in prior processing normspectrum and concwt got
% misalligned. This is an easy way to keep the alignment
for i = 1:nMols     
    Molecule = Molecules(i);
    ConcIn = Molecule.Conc;
    Conc = BestFitConcs(i);
    Molecule.Conc = Conc;
    CWS = Molecule.ConcWtdSpectrum;
    CWSFD = CWS.FreqDomainData;
    if ConcIn > 0
       CWSFD = CWSFD/ConcIn;
       CWSFD = CWSFD*Conc;
    end
    if ConcIn <= 0
       CWSFD = CWSFD * 0.0;
    end
    if Conc <= 0
       CWSFD = CWSFD * 0.0;
    end
    CWS.FreqDomainData = CWSFD;
    Molecule.ConcWtdSpectrum = CWS;
    BestFitMolecules(i) = Molecule;
end

     function [SSE, ModelFD] = FitConcsFunc(Concs)
         nConcs = size(Concs);
         nConcs = nConcs(1);
         for i = 1:nConcs
             ModelFD = Concs(i)*NFDs(:,i);
             if i == 1
                 SumModelFDs = ModelFD;
             else
                 SumModelFDs = SumModelFDs + ModelFD;
             end 
         end
         SSE = ComplexSumSquareError(MeasuredFD, SumModelFDs);
     end
end

