function [oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
          ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                             DefineFourCarbonLabelIndices()

% This function defines the label indices for a four carbon molecule
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg xxox means a four carbon moelcule labelled with C13 at carbons 1, 2
% and 4
% there are no inputs
% returns the numerical values of indices for all possible isotopomers 

oooo = 1;
xooo = 2;
oxoo = 3;
xxoo = 4;

ooxo = 5;
xoxo = 6;
oxxo = 7;
xxxo = 8;

ooox = 9;
xoox = 10;
oxox = 11;
xxox = 12;

ooxx = 13;
xoxx = 14;
oxxx = 15;
xxxx = 16;

end

