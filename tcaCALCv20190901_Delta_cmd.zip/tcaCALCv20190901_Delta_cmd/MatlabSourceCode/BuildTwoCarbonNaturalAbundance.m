function V = BuildTwoCarbonNaturalAbundance(A)
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

A1 = A;
A2 = A*A;

V = zeros(1,4);

V(1, xo) = A1;
V(1, ox) = A1;
V(1, xx) = A2;

T = sum(V(1, :));
V(1, oo) = 1.0 - T;

end

