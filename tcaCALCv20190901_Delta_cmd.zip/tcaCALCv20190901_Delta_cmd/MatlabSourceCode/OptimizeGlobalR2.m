function RMolecule = OptimizeGlobalR2(Molecule, Spectrum, ...
                       TestGlobalR2Low, TestGlobalR2High, ...
                       nTests, PPMLow, PPMHigh)
     
StartValue = TestGlobalR2Low;
ValueInc = (TestGlobalR2High - TestGlobalR2Low)/(nTests-1);
TestValues = zeros(nTests, 1);
for i = 1:nTests
    TestValues(i) = StartValue + ((i-1)*ValueInc);
end
TestR2s = TestValues;

FreqsPPM = Molecule.FreqsPPM;
JAPPM = Molecule.JAPPM;
LabelPattern = Molecule.LabelPattern;
sf = Spectrum.ScannerFreqMHz;
CenterPPM = Spectrum.CenterPPM;
SampleTimesSec = Spectrum.SampleTimesSec;
MolConc = Molecule.Conc;
PlotCenters = Molecule.PlotCenters;
ID = Molecule.ID;

for i = 1:nTests
        TestMolecule = BuildIsotopMolecule(LabelPattern, FreqsPPM, ...
                      JAPPM, MolConc, TestR2s(i), sf, SampleTimesSec, ...
                      CenterPPM);    
        TestMolecule = FitMoleculeConcOverPPMRange(Spectrum, ...
                      TestMolecule, PPMLow, PPMHigh);           
        R = GetResidualOverPPMRange(TestMolecule, Spectrum, PPMLow, PPMHigh);
        if i == 1
            BestR = R;
            BestTestMolecule = TestMolecule;
        end
        if R < BestR
            BestTestMolecule = TestMolecule;
            BestR = R;
        end
end
BestTestMolecule.PlotCenters = PlotCenters;
BestTestMolecule.ID = ID;
RMolecule = BestTestMolecule;
end

