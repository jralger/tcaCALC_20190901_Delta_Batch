function V = GetIsotopomerFromStruct(S, ID)
Q = strsplit(ID, ' ');
Mol = char(Q(1));
IsoID = char(Q(2));

if strcmp(Mol, 'Lac')
    A = S.Lac;
    IDs = BuildIsotopomerIDs(8);
    V = A(strcmp(IDs, IsoID));
end

if strcmp(Mol, 'FA')
    A = S.FA;
    IDs = BuildIsotopomerIDs(4);
    V = A(strcmp(IDs, IsoID));
end

if strcmp(Mol, 'SuccYs')
    A = S.SuccYs;
    IDs = BuildIsotopomerIDs(16);
    V = A(strcmp(IDs, IsoID));
end

if strcmp(Mol, 'Glyc')
    A = S.Glyc;
    IDs = BuildIsotopomerIDs(8);
    V = A(strcmp(IDs, IsoID));
end

if strcmp(Mol, 'CO2')
    A = S.CO2;
    IDs = BuildIsotopomerIDs(2);
    V = A(strcmp(IDs, IsoID));
end

if strcmp(Mol, 'Gln')
    A = S.Gln;
    IDs = BuildIsotopomerIDs(32);
    V = A(strcmp(IDs, IsoID));
end

end

