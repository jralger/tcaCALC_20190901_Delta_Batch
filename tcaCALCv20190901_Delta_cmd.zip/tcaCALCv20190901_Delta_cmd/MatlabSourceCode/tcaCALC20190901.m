function varargout = tcaCALC20190901(varargin)
% TCACALC20190901 MATLAB code for tcaCALC20190901.fig
%      TCACALC20190901, by itself, creates a new TCACALC20190901 or raises the existing
%      singleton*.
%
%      H = TCACALC20190901 returns the handle to a new TCACALC20190901 or the handle to
%      the existing singleton*.
%
%      TCACALC20190901('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TCACALC20190901.M with the given input arguments.
%
%      TCACALC20190901('Property','Value',...) creates a new TCACALC20190901 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tcaCALC20190901_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tcaCALC20190901_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tcaCALC20190901

% Last Modified by GUIDE v2.5 15-Dec-2019 16:43:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tcaCALC20190901_OpeningFcn, ...
                   'gui_OutputFcn',  @tcaCALC20190901_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tcaCALC20190901 is made visible.
function tcaCALC20190901_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tcaCALC20190901 (see VARARGIN)

% Choose default command line output for tcaCALC20190901_v20190901_Delta

% Updated for tcaCALC_v20190901_Delta Sept 11, 2022 J.R. Alger
% In Aug 2022 I received reports of errors that occurred when two substrate
% isotopomers of the same molecule were being fit. For instance when Lac
% oxo and Lac oox when both substrates and were unknown and were being fit.
% In this situation the search routine would lead to situations in which 
% the results reported sum of of the fitted substrates is greater than one
% eg Lac oox + Lac oxo > 1.
% This version handles this problem in the same way that the problem of LDH
% < 0 is handled. It gives such instances a large error value so the search
% routine will prefer to go elsewhere.

% Other tcaCALC_v20190901_Delta changes
% removed various commented blocks used for earlier testing

handles.output = hObject;

%initialize Metabolic model (for GUI input)

% Update handles structure
guidata(hObject, handles);

handles.output = hObject;

DrawModel(handles.axes01, 'Model01.png')
DrawModel(handles.axes02, 'Model02.png')
DrawModel(handles.axes03, 'Model03.png')
DrawModel(handles.axes04, 'Model04.png')
DrawModel(handles.axes05, 'Model05.png')
DrawModel(handles.axes07, 'Model07.png')
DrawModel(handles.axes08, 'Model08.png')
DrawModel(handles.axes09, 'Model09.png')
DrawModel(handles.axes11, 'Model11.png')
DrawModel(handles.axes12, 'Model12.png')
DrawModel(handles.axes13, 'Model13.png')
DrawModel(handles.axes14, 'Model14.png')
DrawModel(handles.axes16, 'Model16.png')

Substrates = SetDefaultSubstrates(1);
handles.SubstratesExactNaturalAbundance = 1;
handles.ExactNaturalAbundance = 1;
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;
handles.Gln = Substrates.Gln;

[o, x] = DefineOneCarbonLabelIndices();
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

NA = Define13CNaturalAbundance();
TA = BuildThreeCarbonNaturalAbundance(NA);
V = Substrates.Lac(1, ooo);
if V < TA(1, ooo)
    handles.LacCheck.Value = 1;
end

V = Substrates.Glyc(1, ooo);
if V < TA(1,ooo)
    handles.GlycCheck.Value = 1;
end

V = Substrates.CO2(1, o);
TA = BuildOneCarbonNaturalAbundance(NA);
if V < TA(1,o)
    handles.CO2Check.Value = 1;
end

TA = BuildFourCarbonNaturalAbundance(NA);
V = Substrates.SuccYs(1, oooo);
if V < TA(1,oooo)
    handles.SuccYsCheck.Value = 1;
end

TA = BuildTwoCarbonNaturalAbundance(NA);
V = Substrates.FA(1, oo);
if V < TA(1,oo)
    handles.FACheck.Value = 1;
end

TA = BuildFiveCarbonNaturalAbundance(NA);
V = Substrates.Gln(1, ooooo);
if V < TA(1,ooooo)
    handles.GlnCheck.Value = 1;
end

MMs = BuildDefaultMetabolicModels4Fit();
handles.MetabolicModels = MMs;
handles.DefaultMetabolicModels = MMs;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tcaCALC20190901 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tcaCALC20190901_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
% varargout{1} = handles.output;



% --- Executes on button press in Load13CSpectrum.
function Load13CSpectrum_Callback(hObject, eventdata, handles)
IsotopomerMultipletAnalysis20200520;


% --- Executes on button press in RuntcaCALC.
function RuntcaCALC_Callback(hObject, eventdata, handles)
CalcMsgBox();
MsgBoxFig = gcf;

% Load starting metabolic model from spreadsheet
% FN = 'C:\Users\Jeffry R Alger\Desktop\tcaCALCEval20190909\MetabolicModels_All.csv';
% MetabolicModels = ReadtcaCALCInputCSV(FN);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% The GUI builds substrates as 1 x nIsotopomers arrays
%%%%% Reading the MetabolicModels from a CSV builds substrates as 
%%%%% nIsotopomers x 1 arrays
%%%%% The MetabolicModel Optimizer (and SimulateIsotopomers) expect 
%%%%% substrates to be nIsotopomers x 1 arrays as read from CSVs
%%%%% The following is kludge to get tcaCALC operational in both modes
%%%%% quickly. 
%%%%% Ideally this should be fixed by rewriting all the GUI software, but
%%%%% don't want to spend the time on this now. Consider doing so for the
%%%%% next release.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handles = ReorientSubstratesIfNeeded(handles);

MetabolicModels = handles.MetabolicModels;
nMMs = size(MetabolicModels, 2);
% for i = 1:nMMs
%     MM = MetabolicModels(1,i);
%     disp(MM.ExptID);
%     T = ['..... XIDs: ', MM.XIDs];
%     disp(T);
%     T = ['..... FA: ', num2str(transpose(MM.FA))];
%     disp(T);
%     T = ['..... SuccYs: ', num2str(transpose(MM.SuccYs))];
%     disp(T);
%     T = ['..... CO2: ', num2str(transpose(MM.CO2))];
%     disp(T);
%     T = ['..... Gln: ', num2str(transpose(MM.Gln))];
%     disp(T);
%     T = ['..... Glyc: ', num2str(transpose(MM.Glyc))];
%     disp(T);
%     T = ['..... Lac: ', num2str(transpose(MM.Lac))];
%     disp(T);
% end

Q = isfield(handles, 'GDA');
if Q
    clear OptMMs
    GDA = handles.GDA;
    GD = GDA(1,1);
    StudyID = GD.StudyID;
    for i = 1:nMMs
        MM = MetabolicModels(1, i);
        MM.tcaCALCID = 'tcaCALC_v20190901_Delta';
        txt = ['Metabolic Fitting: ' , MM.ExptID, ' to ', StudyID];
        disp(txt);
        MM.GDA = GDA;
        OptMM = OptimizeMetabolicModelGDA(MM);
        BestEV = num2str(OptMM.BestEV);
        disp(OptMM.output);     
        txt = ['Error Value: ', BestEV];
        disp(txt);
        OptMMs(1, i) = OptMM;
        disp(' ');
        disp(' ');
    end
    WDN = handles.WDN;
    ReportGDAMMs(OptMMs, WDN);
    PlotGDAModelsResults(OptMMs, WDN);
    disp('Finished');
end

close(MsgBoxFig);
SuccessMsgBox();


% --- Executes on button press in LoadMetabolicModels.
function LoadMetabolicModels_Callback(hObject, eventdata, handles)
[FN,DN,FilterIndex] = uigetfile('*','Identify Metabolic Models Filename:');
FN = [DN, FN];
% FN = 'C:\Users\Jeffry R Alger\Desktop\tcatest\Fasted1Glu\MetabolicModels_All.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_3110_LV_SFit\MM_MetabolicModels_All_SFit.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_3110_LV_SFit\MM_BadModels.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_3110_LV_SFit\MM_MetabolicModels_Good_SFit.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_3110_LV_SFit\MM_3110_LV_SFit_All_Model_Best\MM_MetabolicModels_All_SFit_Bounded_Best.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\New folder\H1_05052022_N\MetabolicModelsAll_CK.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_tcaCALC_20150622\Heart8x\MetabolicModelsAll_MM.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_tcaCALC_20150622\Heart8x\MetabolicModelsBest_MM.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_tcaCALC_20220817_retest\MM_3110_LV_SFit\MM_MetabolicModels_All_SFit.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\TestDelta\MM_3110_LV_NoSFit\MM_MetabolicModels_All_NoSFit.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\TestDelta\MM_3110_LV_SFit\MM_MetabolicModels_All_SFit.csv';
MetabolicModels = ReadtcaCALCInputCSV(FN);

% Here there should be an error check for the MetabolicModels
% specifically for substrate entry errors (ie substrate isotopomers < 0 or
% > 1) also for rate errors (PDH, YPC, YS, PK < 0 and/or PDH > 1)
% there is considerable coding associated with this and then managing
% the error to let user know what is wrong
% This coding is too big a job for this version
% instead warn user to double check their input in the documentation

handles.MetabolicModels = MetabolicModels;
guidata(hObject, handles);


% --- Executes on button press in LoadGenData.
function LoadGenData_Callback(hObject, eventdata, handles)
[FN,DN,FilterIndex] = uigetfile('*','Identify Filename:'); 
FN = [DN, FN];
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_3110_LV_SFit\MM_3110_LV_SFit_All_Model_Best\MM_GDAInput.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\New folder\H1_05052022_N\H1_05052022_NF_for_Jeff.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_tcaCALC_20150622\Heart8x\Heart8xGDA.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\MM_tcaCALC_20220817_retest\MM_3110_LV_SFit\MM_GDAInput.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\TestDelta\MM_3110_LV_NoSFit\MM_GDAInput.csv';
% FN = 'C:\Users\Jeffry R Alger\Desktop\TestDelta\MM_3110_LV_SFit\MM_GDAInput.csv';
[DN, SpectrumID, Ext] = fileparts(FN);

EIDs = {'.txt', '.TXT', '.dat', '.DAT'};
if any(strcmp(EIDs, Ext))
    CMDAT = ReadOneCMDAT(FN);
    GDA = CMDAT2GDA(CMDAT, FN, SpectrumID);
%     nGDA = size(GDA, 2);
%     for j = 1:nGDA
%         GD = GDA(1,j);
%         disp(GD);
%     end
    handles.GDA = GDA;
end

EIDs = {'.csv', '.CSV'};
if any(strcmp(EIDs, Ext))
    if contains(SpectrumID, 'MultipletResults')
        RA = ReadOneMAcsv(FN);
        GDA = MA2GDA(RA, FN);
        handles.GDA = GDA;
    else
        GDA = ReadGDACSV(FN);
        handles.GDA = GDA;
    end
end

handles.WDN = [DN, '\'];

guidata(hObject, handles);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  Substrate Entry Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in FACheck.
function FACheck_Callback(hObject, eventdata, handles)
FA = handles.FA;
MolID = 'Acetate (Fatty Acid Equivalent)';
FA = InputTwoCarbonIsotopomers('InputFA', MolID, FA);
handles.FA = FA;
handles = UpdateMetabolicModelsSubstrates(handles, FA, 'FA');
Z = handles.FACheck;
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildTwoCarbonNaturalAbundance(NA);
if FA(1,oo) < TA(1,oo);
    Z.Value = 1;
    handles.FACheck = Z;
end
if FA(1,oo) >= TA(1,oo)
    Z.Value = 0;
    handles.FACheck = Z;
end
guidata(hObject, handles);


% --- Executes on button press in SuccYsCheck.
function SuccYsCheck_Callback(hObject, eventdata, handles)
SuccYs = handles.SuccYs;
MolID = 'SuccYs';
SuccYs = InputFourCarbonIsotopomers('InputSuccYs', MolID, SuccYs);
handles.SuccYs = SuccYs;
handles = UpdateMetabolicModelsSubstrates(handles, SuccYs, 'SuccYs');
Z = handles.SuccYsCheck;
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, ~, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                     DefineFourCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildFourCarbonNaturalAbundance(NA);
if SuccYs(1,oooo) < TA(1, oooo)
    Z.Value = 1;
    handles.SuccYsCheck = Z;
end
if SuccYs(1,oooo) >= TA(1, oooo)
    Z.Value = 0;
    handles.SuccYsCheck = Z;
end
guidata(hObject, handles);


% --- Executes on button press in LacCheck.
function LacCheck_Callback(hObject, eventdata, handles)
Lac = handles.Lac;
MolID = 'Lactate';
Lac = InputThreeCarbonIsotopomers('InputLac', MolID, Lac);
handles.Lac = Lac;
handles = UpdateMetabolicModelsSubstrates(handles, Lac, 'Lac');
Z = handles.LacCheck;
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildThreeCarbonNaturalAbundance(NA);
if Lac(1,ooo) < TA(1,ooo)
    Z.Value = 1;
    handles.LacCheck = Z;
end
if Lac(1,ooo) >= TA(1,ooo)
    Z.Value = 0;
    handles.LacCheck = Z;
end
guidata(hObject, handles);


% --- Executes on button press in CO2Check.
function CO2Check_Callback(hObject, eventdata, handles)
CO2 = handles.CO2;
MolID = 'CO2 (Bicarbonate)';
CO2 = InputOneCarbonIsotopomers('InputCO2', MolID, CO2);
handles.CO2 = CO2;
handles = UpdateMetabolicModelsSubstrates(handles, CO2, 'CO2');
Z = handles.CO2Check;
[o, x] = DefineOneCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildOneCarbonNaturalAbundance(NA);
if CO2(1,o) < TA(1,o)
    Z.Value = 1;
    handles.CO2Check = Z;
end
if CO2(1,o) >= TA(1,o)
    Z.Value = 0;
    handles.CO2Check = Z;
end
guidata(hObject, handles);


% --- Executes on button press in GlnCheck.
function GlnCheck_Callback(hObject, eventdata, handles)
Gln = handles.Gln;
MolID = 'Glutamine';
Gln = InputFiveCarbonIsotopomers('InputGln', MolID, Gln);
handles.Gln = Gln;
handles = UpdateMetabolicModelsSubstrates(handles, Gln, 'Gln');
Z = handles.GlnCheck;
                                
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildFiveCarbonNaturalAbundance(NA);
if Gln(1,ooooo) < TA(1,ooooo)
    Z.Value = 1;
    handles.GlnCheck = Z;
end
if Gln(1,ooooo) >= TA(1,ooooo)
    Z.Value = 0;
    handles.GlnCheck = Z;
end
guidata(hObject, handles);


% --- Executes on button press in GlycCheck.
function GlycCheck_Callback(hObject, eventdata, handles)
Glyc = handles.Glyc;
MolID = 'Glycerol';
Glyc = InputThreeCarbonIsotopomers('InputGlyc', MolID, Glyc);
handles.Glyc = Glyc;
handles = UpdateMetabolicModelsSubstrates(handles, Glyc, 'Glyc');
Z = handles.GlycCheck;
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
NA = 0;
if handles.SubstratesExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
TA = BuildThreeCarbonNaturalAbundance(NA);
if Glyc(1,ooo) < TA(1,ooo)
    Z.Value = 1;
    handles.GlycCheck = Z;
end
if Glyc(1,ooo) >= TA(1,ooo)
    Z.Value = 0;
    handles.GlycCheck = Z;
end
guidata(hObject, handles);


% --- Executes on button press in CBSubstrateExactNA.
function CBSubstrateExactNA_Callback(hObject, eventdata, handles)
SubstratesExactNaturalAbundance = get(hObject,'Value');
handles.SubstratesExactNaturalAbundance = SubstratesExactNaturalAbundance;
Substrates = SetDefaultSubstrates(SubstratesExactNaturalAbundance);
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;
handles.Gln = Substrates.Gln;
handles.LacCheck.Value = 0;
handles.GlycCheck.Value = 0;
handles.CO2Check.Value = 0;
handles.SuccYsCheck.Value = 0;
handles.FACheck.Value = 0;
handles.GlnCheck.Value = 0;

MMs = handles.MetabolicModels;
nMMs = size(MMs,2);
for i = 1:nMMs
    MM = MMs(1,i);
    MM.Lac = Substrates.Lac;
    MM.FA = Substrates.FA;
    MM.CO2 = Substrates.CO2;
    MM.Glyc = Substrates.Glyc;
    MM.SuccYs = Substrates.SuccYs;
    MM.Gln = Substrates.Gln;
    MMs(1,i) = MM;
end
handles.MetabolicModels = MMs;
guidata(hObject, handles);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  END:::: Substrate Entry Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  Fit Checkbox Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% --- Executes on button press in FitFACB.
function FitFACB_Callback(hObject, eventdata, handles)
MolID = 'FA';
nIsotopomers = 4;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);

% --- Executes on button press in FitSuccYsCB.
function FitSuccYsCB_Callback(hObject, eventdata, handles)
MolID = 'SuccYs';
nIsotopomers = 16;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);

% --- Executes on button press in FitBicCB.
function FitBicCB_Callback(hObject, eventdata, handles)
MolID = 'CO2';
nIsotopomers = 2;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);

% --- Executes on button press in FitGlnCB.
function FitGlnCB_Callback(hObject, eventdata, handles)
MolID = 'Gln';
nIsotopomers = 32;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);

% --- Executes on button press in FitGlycCB.
function FitGlycCB_Callback(hObject, eventdata, handles)
MolID = 'Glyc';
nIsotopomers = 8;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);

% --- Executes on button press in FitLacCB.
function FitLacCB_Callback(hObject, eventdata, handles)
MolID = 'Lac';
nIsotopomers = 8;
handles = AddNewXID(handles, MolID, nIsotopomers);
guidata(hObject, handles);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  Model Reset Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in Model01CB.
function Model01CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model02CB.
function Model02CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model03CB.
function Model03CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model04CB.
function Model04CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model05CB.
function Model05CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model07CB.
function Model07CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model08CB.
function Model08CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model09CB.
function Model09CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model11CB.
function Model11CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model12CB.
function Model12CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model13CB.
function Model13CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model14CB.
function Model14CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in Model16CB.
function Model16CB_Callback(hObject, eventdata, handles)
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

% --- Executes on button press in ModelsAllCB.
function ModelsAllCB_Callback(hObject, eventdata, handles)
handles.CBNoAnaplerosis.Value = 0;
handles.CBNoPK.Value = 0;
handles.CBNoYs.Value = 0;
CBA = [handles.Model01CB, handles.Model02CB, handles.Model03CB, ...
       handles.Model04CB, handles.Model05CB, handles.Model07CB, ...
       handles.Model08CB, handles.Model09CB, handles.Model11CB, ...
       handles.Model12CB, handles.Model13CB, handles.Model14CB, ...
       handles.Model16CB];
for i = 1:13
    CB = CBA(i);
    CB.Value = 1;
    CBA(i) = CB;
end
handles = ResetModelDisplays(handles);
guidata(hObject, handles);


% --- Executes on button press in CBNoAnaplerosis.
function CBNoAnaplerosis_Callback(hObject, eventdata, handles)
PBV = get(hObject,'Value');
if PBV == 1
    handles.CBNoYs.Value = 0;
    handles.CBNoPK.Value = 0;
    handles.ModelsAllCB.Value = 0;
    handles.Model01CB.Value = 0;
    handles.Model02CB.Value = 0;
    handles.Model03CB.Value = 0;
    handles.Model04CB.Value = 0;
    handles.Model05CB.Value = 0;
    handles.Model07CB.Value = 0;
    handles.Model08CB.Value = 0;
    handles.Model09CB.Value = 0;
    handles.Model11CB.Value = 0;
    handles.Model13CB.Value = 0;
    handles.Model14CB.Value = 0;
    handles.Model12CB.Value = 1;
    handles.Model16CB.Value = 1;
end
if PBV == 0
    handles.CBNoYs.Value = 0;
    handles.CBNoPK.Value = 0;
    handles.ModelsAllCB.Value = 1;
    handles.Model01CB.Value = 1;
    handles.Model02CB.Value = 1;
    handles.Model03CB.Value = 1;
    handles.Model04CB.Value = 1;
    handles.Model05CB.Value = 1;
    handles.Model07CB.Value = 1;
    handles.Model08CB.Value = 1;
    handles.Model09CB.Value = 1;
    handles.Model11CB.Value = 1;
    handles.Model13CB.Value = 1;
    handles.Model14CB.Value = 1;
    handles.Model12CB.Value = 1;
    handles.Model16CB.Value = 1;
end
handles = ResetModelDisplays(handles);
guidata(hObject, handles);


% --- Executes on button press in CBNoPK.
function CBNoPK_Callback(hObject, eventdata, handles)
PBV = get(hObject,'Value');
if PBV == 1
    handles.CBNoAnaplerosis.Value = 0;
    handles.CBNoYs.Value = 0;
    handles.ModelsAllCB.Value = 0;
    handles.Model01CB.Value = 0;
    handles.Model03CB.Value = 0;
    handles.Model04CB.Value = 0;
    handles.Model05CB.Value = 0;
    handles.Model09CB.Value = 0;
    handles.Model02CB.Value = 1;
    handles.Model07CB.Value = 1;
    handles.Model08CB.Value = 1;
    handles.Model11CB.Value = 1;
    handles.Model12CB.Value = 1;
    handles.Model13CB.Value = 1;
    handles.Model14CB.Value = 1;
    handles.Model16CB.Value = 1;
end
if PBV == 0
    handles.CBNoYs.Value = 0;
    handles.CBNoAnaplerosis.Value = 0;
    handles.ModelsAllCB.Value = 1;
    handles.Model01CB.Value = 1;
    handles.Model02CB.Value = 1;
    handles.Model03CB.Value = 1;
    handles.Model04CB.Value = 1;
    handles.Model05CB.Value = 1;
    handles.Model07CB.Value = 1;
    handles.Model08CB.Value = 1;
    handles.Model09CB.Value = 1;
    handles.Model11CB.Value = 1;
    handles.Model13CB.Value = 1;
    handles.Model14CB.Value = 1;
    handles.Model12CB.Value = 1;
    handles.Model16CB.Value = 1;
end
handles = ResetModelDisplays(handles);
guidata(hObject, handles);


% --- Executes on button press in CBNoAnaplerosis.
function CBNoYs_Callback(hObject, eventdata, handles)
PBV = get(hObject,'Value');
if PBV == 1
    handles.CBNoAnaplerosis.Value = 0;
    handles.CBNoPK.Value = 0;
    handles.ModelsAllCB.Value = 0;
    handles.Model01CB.Value = 0;
    handles.Model02CB.Value = 0;
    handles.Model03CB.Value = 0;
    handles.Model04CB.Value = 0;
    handles.Model08CB.Value = 0;
    handles.Model11CB.Value = 0;
    handles.Model13CB.Value = 0;
    handles.Model05CB.Value = 1;
    handles.Model07CB.Value = 1;
    handles.Model09CB.Value = 1;
    handles.Model12CB.Value = 1;
    handles.Model14CB.Value = 1;
    handles.Model16CB.Value = 1;
end
if PBV == 0
    handles.CBNoPK.Value = 0;
    handles.CBNoAnaplerosis.Value = 0;
    handles.ModelsAllCB.Value = 1;
    handles.Model01CB.Value = 1;
    handles.Model02CB.Value = 1;
    handles.Model03CB.Value = 1;
    handles.Model04CB.Value = 1;
    handles.Model05CB.Value = 1;
    handles.Model07CB.Value = 1;
    handles.Model08CB.Value = 1;
    handles.Model09CB.Value = 1;
    handles.Model11CB.Value = 1;
    handles.Model13CB.Value = 1;
    handles.Model14CB.Value = 1;
    handles.Model12CB.Value = 1;
    handles.Model16CB.Value = 1;
end
handles = ResetModelDisplays(handles);
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  END: Model Reset Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on button press in DisplayParameters.
function DisplayParameters_Callback(hObject, eventdata, handles)
MMs = handles.MetabolicModels;
MMs = DefaultSettings(MMs);
handles.MetabolicModels = MMs;
guidata(hObject, handles);
% nMMs = size(MMs, 2);
% for i = 1:nMMs
%     MM = MMs(1,i);
% %     disp(num2str(MM.PDH));
% end
% dummy = 1;


% --- Executes on button press in CompletePathwayDiagram.
function CompletePathwayDiagram_Callback(hObject, eventdata, handles)
DisplayPathwayDiagram;



% --- Executes on button press in Quit.
function Quit_Callback(hObject, eventdata, handles)
close all;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Helper functions begin here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DrawModel(ax, FN)
axes(ax);
cla;
imshow(FN);
axis off;



function handles = UpdateMetabolicModelsSubstrates(handles, SA, SID)
MMs = handles.MetabolicModels;
nMMs = size(MMs, 2);
for i = 1:nMMs
    MM = MMs(1,i);
    MM.(SID) = SA;
    MMs(1,i) = MM;
end
handles.MetabolicModels = MMs;


function handles = ResetModelDisplays(handles)
AxA = [handles.axes01, handles.axes02, handles.axes03, ...
       handles.axes04, handles.axes05, handles.axes07, ...
       handles.axes08, handles.axes09, handles.axes11, ...
       handles.axes12, handles.axes13, handles.axes14, ...
       handles.axes16];
CBA = [handles.Model01CB, handles.Model02CB, handles.Model03CB, ...
       handles.Model04CB, handles.Model05CB, handles.Model07CB, ...
       handles.Model08CB, handles.Model09CB, handles.Model11CB, ...
       handles.Model12CB, handles.Model13CB, handles.Model14CB,...
       handles.Model16CB];
PNGA = {'Model01.png', 'Model02.png', 'Model03.png', ...
        'Model04.png', 'Model05.png', 'Model07.png', ...
        'Model08.png', 'Model09.png', 'Model11.png', ...
        'Model12.png', 'Model13.png', 'Model14.png', ...
        'Model16.png'};

for i = 1:13
    CB = CBA(i);
    V = CB.Value;
    Ax = AxA(i);
    axes(Ax);
    cla;
    FN = char(PNGA(i));
    if V == 1
        imshow(FN);
    end
end
Z = handles.ModelsAllCB;
if V == 0
    Z.Value = 0;
end
VA = [];
for i = 1:13
    CB = CBA(i);
    V = CB.Value;
    VA(i) = V;
end
Z.Value = 0;
if all(VA)
    Z.Value = 1;
end
handles.ModelsAllCB = Z;

DMMs = handles.DefaultMetabolicModels;
N = 1;
for i = 1:13
    CB = CBA(i);
    V = CB.Value;
    if V == 1
        DMM = DMMs(1,i);
        MMs(1, N) = DMM;
        N = N + 1;
    end
end
handles.MetabolicModels = MMs;


function handles = AddNewXID(handles, MolID, nIsotopomers)
SA = handles.(MolID);
XOs = BuildIsotopomerIDs(nIsotopomers);
NA = 0.0;
if handles.ExactNaturalAbundance == 1
    NA = Define13CNaturalAbundance();
end
if nIsotopomers == 2
    SANA = BuildOneCarbonNaturalAbundance(NA);
end
if nIsotopomers == 4
    SANA = BuildTwoCarbonNaturalAbundance(NA);
end
if nIsotopomers == 8
    SANA = BuildThreeCarbonNaturalAbundance(NA);
end
if nIsotopomers == 16
    SANA = BuildFourCarbonNaturalAbundance(NA);
end
if nIsotopomers == 32
    SANA = BuildFiveCarbonNaturalAbundance(NA);
end
LXOs = XOs(SA > SANA);
nLXOs = size(LXOs, 2);
if nLXOs == 1
    XO = char(LXOs(1,1));
    NXID = {[MolID, ' ', XO]};
    MMs = handles.MetabolicModels;
    nMMs = size(MMs, 2);
    for i = 1:nMMs
        MM = MMs(1,i);
        XIDs = MM.XIDs;
        nXIDs = size(XIDs, 2);
        XIDs(1, nXIDs+1) = NXID;
        MM.XIDs = XIDs;
        MMs(1, i) = MM;
    end
    handles.MetabolicModels = MMs;
else
    PID = ['Fit', MolID, 'CB'];
    if strcmp(MolID, 'CO2')
        PID = ['FitBicCB'];
    end
    Z = handles.(PID);
    Z.Value = 0;
    handles.(PID) = Z;
end


function handles = ReorientSubstratesIfNeeded(handles)

SIDs = {'Lac', 'FA', 'CO2', 'Glyc', 'SuccYs', 'Gln'};
nSIDs = size(SIDs, 2);
for i = 1:nSIDs
    SID = char(SIDs(1,i));
    V = handles.(SID);
    nV = size(V);
    if nV(2) > nV(1)
        VT = transpose(V);
        handles.(SID) = VT;
    end
end

MMs = handles.MetabolicModels;
nMMs = size(MMs, 2);
for j = 1:nMMs
    MM = MMs(1,j);
    for i = 1:nSIDs
        SID = char(SIDs(1,i));
        V = MM.(SID);
        nV = size(V);
        if nV(2) > nV(1)
            VT = transpose(V);
            MM.(SID) = VT;
        end
    end
    MMs(1,j) = MM;
end
handles.MetabolicModels = MMs;




