% This is a branch of tcaCALC20190901 Delta designed for batch or command
% line use
% December 11, 2024 
% J.R. Alger

% Intent was to make this into a command line executable
% It is easy to run from the Matlab DE and edit the working directory so
% postpone development of command line executable for the future

% Does not call or use the GUI, although the code for doing this is
% included in the distribution
% All input comes from two .csv spreadsheets as follows
% one spreadsheet describes the metabolic models to be tested
% the second spreadsheet describes the measured data. Only the General
% Data Array (GDA) measured data spreadsheet is supported
% No error checking of input files is performed. it is the users
% responsiblity to build the input spreadsheets correctly
% All output is written to the directory that contains the GDA spreadsheet

% This version does not support 13C spectral fitting (although all the spectral
% fitting code is included in the distribution)

% Studies to be analyzed should exist as subfolders of a working directory
% (WD). The subfolders can have any names that are legal for the OS.

% each subdirectory should contain two .csv files named as follows
% one .csv file contains the measured data identified as GDAID below
% the other .csv file contains the metabolic models identified as MMID

% Working directory ID
% if working in the matlab DE this can be edited to point to the data
% WD = 'C:\Users\JeffryRAlger\Desktop\TestDelta';
WD = 'C:\Users\JeffryRAlger\Desktop\JakeExperimentalData';

%ID for GDA filenames
% GDAID = 'GDA_*.csv';
GDAID = '*_GDA_*.csv';

%ID for Metabolic Models filenames
% MMID = 'MetabolicModels_*.csv';
MMID = '*_MetabolicModels_*.csv';

% run tcaCalc in batch mode
tcaCALC_Delta_Batch(WD, GDAID, MMID);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% basic function that runs tcaCALC_Delta as a batch
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function tcaCALC_Delta_Batch(WDID, GDAID, MMID)

% search key for GDA filenames
GDASK = fullfile(WDID, '*', GDAID);

%get all GDA dilenames
GDAFNA = dir(GDASK);
nGDA = size(GDAFNA, 1); 

% run tcaCALC for each GDA file
for i = 1:nGDA
    GDAFN = GDAFNA(i, 1);
    SK = fullfile(GDAFN.folder, MMID);
    MMFNA = dir(SK);
    nMMFNA = size(MMFNA, 1);
    if nMMFNA == 1
        % GDA filename
        GDAFN = fullfile(GDAFN.folder, GDAFN.name);
        % Metabolic Model filename
        MMFN = fullfile(MMFNA.folder, MMFNA.name);
        run_tcaCALC_Delta(MMFN, GDAFN);
        close all;
    end
end
end % end of function tcaCALC_Delta_Batch


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% basic function that runs tcaCALC_Delta without using GUI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function run_tcaCALC_Delta(MMFN, GDAFN)

% MMFN is the full path filename of the .csv spreadsheet that 
% describes the metabolic models
% GDAFN is the filename of .csv spreadsheet that describes the measured
% data

% read the metabolic models spreadsheet
MetabolicModels = ReadtcaCALCInputCSV(MMFN);

% Here there should be an error check for the MetabolicModels
% specifically for substrate entry errors (ie substrate isotopomers < 0 or
% > 1) also for rate errors (PDH, YPC, YS, PK < 0 and/or PDH > 1)
% there is considerable coding associated with this and then managing
% the error to let user know what is wrong
% This coding is too big a job for this version
% instead warn user to double check their input in the documentation

% read the measured data
[GDADN, SpectrumID, Ext] = fileparts(GDAFN);
GDA = ReadGDACSV(GDAFN);
% GDADN is the directory name to which output will be written
% SpectrumID is an identifier taken from the filename used in nameing 
% output file

% initialize the structure that will hold all data
% This structure is named 'handles' identically with the GUI version 
% although it does not contain any of the variables/parameters used in GUI
handles = struct;

% set up default substrates
Substrates = SetDefaultSubstrates(1);
handles.SubstratesExactNaturalAbundance = 1;
handles.ExactNaturalAbundance = 1;
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;
handles.Gln = Substrates.Gln;

[o, x] = DefineOneCarbonLabelIndices();
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

NA = Define13CNaturalAbundance();
TA = BuildThreeCarbonNaturalAbundance(NA);
V = Substrates.Lac(1, ooo);
if V < TA(1, ooo)
    handles.LacCheck.Value = 1;
end

V = Substrates.Glyc(1, ooo);
if V < TA(1,ooo)
    handles.GlycCheck.Value = 1;
end

V = Substrates.CO2(1, o);
TA = BuildOneCarbonNaturalAbundance(NA);
if V < TA(1,o)
    handles.CO2Check.Value = 1;
end

TA = BuildFourCarbonNaturalAbundance(NA);
V = Substrates.SuccYs(1, oooo);
if V < TA(1,oooo)
    handles.SuccYsCheck.Value = 1;
end

TA = BuildTwoCarbonNaturalAbundance(NA);
V = Substrates.FA(1, oo);
if V < TA(1,oo)
    handles.FACheck.Value = 1;
end

TA = BuildFiveCarbonNaturalAbundance(NA);
V = Substrates.Gln(1, ooooo);
if V < TA(1,ooooo)
    handles.GlnCheck.Value = 1;
end

% build default metabolic models
MMs = BuildDefaultMetabolicModels4Fit();
handles.MetabolicModels = MMs;
handles.DefaultMetabolicModels = MMs;

% assign the Metabolic Models that have been read from the .csv
handles.MetabolicModels = MetabolicModels;

% assign the GDA measured data that has been read
handles.GDA = GDA;

% build the output write directory name
handles.WDN = [GDADN, '\'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% The GUI builds substrates as 1 x nIsotopomers arrays
%%%%% Reading the MetabolicModels from a CSV builds substrates as 
%%%%% nIsotopomers x 1 arrays
%%%%% The MetabolicModel Optimizer (and SimulateIsotopomers) expect 
%%%%% substrates to be nIsotopomers x 1 arrays as read from CSVs
%%%%% The following is kludge to get tcaCALC operational in both modes
%%%%% quickly. 
%%%%% Ideally this should be fixed by rewriting all the GUI software, but
%%%%% don't want to spend the time on this now. Consider doing so for the
%%%%% next release.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This may not be needed because the GUI is not used
handles = ReorientSubstratesIfNeeded(handles);

% perform the metabolic model fitting
MetabolicModels = handles.MetabolicModels;
nMMs = size(MetabolicModels, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% code for debugging (could be deleted)
% for i = 1:nMMs
%     MM = MetabolicModels(1,i);
%     disp(MM.ExptID);
%     T = ['..... XIDs: ', MM.XIDs];
%     disp(T);
%     T = ['..... FA: ', num2str(transpose(MM.FA))];
%     disp(T);
%     T = ['..... SuccYs: ', num2str(transpose(MM.SuccYs))];
%     disp(T);
%     T = ['..... CO2: ', num2str(transpose(MM.CO2))];
%     disp(T);
%     T = ['..... Gln: ', num2str(transpose(MM.Gln))];
%     disp(T);
%     T = ['..... Glyc: ', num2str(transpose(MM.Glyc))];
%     disp(T);
%     T = ['..... Lac: ', num2str(transpose(MM.Lac))];
%     disp(T);
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for this version GDA is always present in handles
Q = isfield(handles, 'GDA');
if Q
    clear OptMMs
    GDA = handles.GDA;
    GD = GDA(1,1);
    StudyID = GD.StudyID;
    for i = 1:nMMs
        MM = MetabolicModels(1, i);
        MM.tcaCALCID = 'tcaCALC_v20190901_Delta_CLI';
        txt = ['Metabolic Fitting: ' , MM.ExptID, ' to ', StudyID];
        disp(txt);
        MM.GDA = GDA;
        OptMM = OptimizeMetabolicModelGDA(MM);
        BestEV = num2str(OptMM.BestEV);
        disp(OptMM.output);     
        txt = ['Error Value: ', BestEV];
        disp(txt);
        OptMMs(1, i) = OptMM;
        disp(' ');
        disp(' ');
    end
    WDN = handles.WDN;
    ReportGDAMMs(OptMMs, WDN);
    PlotGDAModelsResults(OptMMs, WDN);
    disp('Finished run_tcaCALC_Delta');
    disp(' ');
    disp(' ');
    disp(' ');
    disp(' ');
    disp(' ');
end

end %end run_tcaCALC_Delta



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Helper function that reorients the substrates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function handles = ReorientSubstratesIfNeeded(handles)

SIDs = {'Lac', 'FA', 'CO2', 'Glyc', 'SuccYs', 'Gln'};
nSIDs = size(SIDs, 2);
for i = 1:nSIDs
    SID = char(SIDs(1,i));
    V = handles.(SID);
    nV = size(V);
    if nV(2) > nV(1)
        VT = transpose(V);
        handles.(SID) = VT;
    end
end

MMs = handles.MetabolicModels;
nMMs = size(MMs, 2);
for j = 1:nMMs
    MM = MMs(1,j);
    for i = 1:nSIDs
        SID = char(SIDs(1,i));
        V = MM.(SID);
        nV = size(V);
        if nV(2) > nV(1)
            VT = transpose(V);
            MM.(SID) = VT;
        end
    end
    MMs(1,j) = MM;
end
handles.MetabolicModels = MMs;
end



