function handles = AddMolecule(handles, Molecule);
if ~isfield(handles, 'Molecules')
    Molecules = [Molecule];
else
   Molecules = handles.Molecules;
   nM = size(Molecules,1);
   ID = Molecule.ID;
   Replaced = 0;
   for i=1:nM
       TestMolecule = Molecules(i);
       TestID = TestMolecule.ID;
       if strmatch(ID, TestID, 'exact')
           Molecules(i) = Molecule;
           Replaced = 1;
       end
   end
   if Replaced == 0       
      Molecules = cat(1, Molecules, Molecule);
   end
end
handles.Molecules = Molecules;
end

