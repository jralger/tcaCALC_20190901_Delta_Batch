function RMolecules = RunIndependentMoleculeFits(Spectrum, Molecules, ...
         TestGlobalR2Low, TestGlobalR2High);
RMolecules = Molecules;
nM = size( Molecules,1);
PPMTable = Spectrum.PPMTable;
D = PPMTable(1) - PPMTable(2);
TestFreqsPPMRange = 4.0*D;
TestFreqsPPMInc = 0.1*D;
% TestGlobalR2Low = 1.0;
% TestGlobalR2High = 10.0;
nR2Tests = 10;
SF = Spectrum.ScannerFreqMHz;
TestJhzRange = 3.0;
TestJhzInc = 0.1;
TestJPPMRange = TestJhzRange/SF;
TestJPPMInc = TestJhzInc/SF;
RatioThreshold = 0.05;
SingletCalcRangePPM = 25.0*D;
nopts = 1;
h = waitbar(0, 'Please wait: Preliminary stage of multiplet fitting is in progress');
for i = 1:nM
    Molecule = Molecules(i);
    JAPPM = Molecule.JAPPM;
    maxJAPPM = max(JAPPM);
    maxJAPPM = max(maxJAPPM);
    CalcPPMRangeLow = -3.0*maxJAPPM/2.0;
    CalcPPMRangeHigh = 3.0*maxJAPPM/2.0;
    if maxJAPPM == 0.0
       CalcPPMRangeLow = -SingletCalcRangePPM/2.0;
       CalcPPMRangeHigh = SingletCalcRangePPM/2.0;
    end
    ID = Molecule.ID;
    FreqPPM = Molecule.PlotCenters;
    PPMLow = FreqPPM + CalcPPMRangeLow;
    PPMHigh = FreqPPM + CalcPPMRangeHigh;
    Molecule = EstimateConcByRatio(Molecule, Spectrum, ...
                       RatioThreshold);
    Molecule = FitMoleculeConcOverPPMRange(Spectrum, ...
                       Molecule, PPMLow, PPMHigh);   
    for j = 1:nopts
        Molecule = OptimizeOneFreqOnOneMolecule(Molecule, Spectrum, ...
            TestFreqsPPMRange, TestFreqsPPMInc, ...
            PPMLow, PPMHigh);
%         Molecule = OptimizeJAPPMOnOneMolecule(Molecule, Spectrum, ...
%             TestJPPMRange, TestJPPMInc, ...
%             PPMLow, PPMHigh);
        Molecule = OptimizeGlobalR2(Molecule, Spectrum, ...
            TestGlobalR2Low, TestGlobalR2High, ...
            nR2Tests, PPMLow, PPMHigh);
    end
    IntWidthPPM = PPMHigh - PPMLow;
    Molecule = IntegrateMoleculeSpectrum(Molecule, IntWidthPPM);
    RMolecules(i) = Molecule;
    waitbar(i/nM);
end
close(h);
end

