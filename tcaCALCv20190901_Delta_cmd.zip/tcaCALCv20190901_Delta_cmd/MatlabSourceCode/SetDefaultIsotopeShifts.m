function IsoShiftArr = SetDefaultIsotopeShifts()
% sets default values of isotope shifts in PPM

%Isotope shifts (in PPM). Add the value of dPPM to the Singlet
% center ppm to obtain the multiplet center ppm
      
% updated Isotope shifts done 14 Aug 2017 (average of 6 high quality Agilent
% spectra after full hand picking and full fitting
    
N = 1;
IsoShiftArr(N, 1).ID =  'Asp C1 D';
IsoShiftArr(N, 1).dPPM = 0.00055;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C2 D12';
IsoShiftArr(N, 1).dPPM = -0.00845;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C2 D23';
IsoShiftArr(N, 1).dPPM = -0.00528;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C2 Q';
IsoShiftArr(N, 1).dPPM = -0.01405;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C3 D34';
IsoShiftArr(N, 1).dPPM = -0.01015;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C3 D23';
IsoShiftArr(N, 1).dPPM = -0.01197;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Asp C3 Q';
IsoShiftArr(N, 1).dPPM = -0.02167;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C1 D';
IsoShiftArr(N, 1).dPPM = 0.000383;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C2 D12';
IsoShiftArr(N, 1).dPPM = -0.00915;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C2 D23';
IsoShiftArr(N, 1).dPPM = -0.00465;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C2 Q';
IsoShiftArr(N, 1).dPPM = -0.01382;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C3 D';
IsoShiftArr(N, 1).dPPM = -0.01223;
N = N + 1;

% IsoShiftArr(N, 1).ID =  'Glu C3 D34';
% IsoShiftArr(N, 1).dPPM = -0.01223;
% N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C3 T';
IsoShiftArr(N, 1).dPPM = -0.01928;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C4 D34';
IsoShiftArr(N, 1).dPPM = -0.00553;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C4 D45';
IsoShiftArr(N, 1).dPPM = -0.01032;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C4 Q';
IsoShiftArr(N, 1).dPPM = -0.01677;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Glu C5 D';
IsoShiftArr(N, 1).dPPM = -0.00057;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Lac C1 D';
IsoShiftArr(N, 1).dPPM = -0.000233;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Lac C2 D12';
IsoShiftArr(N, 1).dPPM = -0.01195;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Lac C2 D23';
IsoShiftArr(N, 1).dPPM = -0.00582;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Lac C2 Q';
IsoShiftArr(N, 1).dPPM = -0.01645;
N = N + 1;

IsoShiftArr(N, 1).ID =  'Lac C3 D';
IsoShiftArr(N, 1).dPPM = -0.01093;
N = N + 1;
      
;

end

