function V = ReadCMDAT(FN, ID, C2N)
V = '-1';
fileID = fopen(FN, 'r');
A = 'A';
while ischar(A)
      A = fgetl(fileID);
      if ischar(A)
          Q = strfind(A, ID);
          if Q
              B = strsplit(A, ' ');
              nB = size(B, 2);
              C = char(B(nB));
              C = strsplit(C, ID);
              nC = size(C, 2);
              V = char(C(nC));   
          end
      end
end          
fclose(fileID);
if C2N
   V = str2double(V);
end

end

