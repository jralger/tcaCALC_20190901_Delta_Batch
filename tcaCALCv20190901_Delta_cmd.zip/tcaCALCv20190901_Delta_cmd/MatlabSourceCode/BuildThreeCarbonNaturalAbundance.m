function V = BuildThreeCarbonNaturalAbundance(A)
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                          DefineThreeCarbonLabelIndices();

A1 = A;
A2 = A*A;
A3 = A*A*A;

V = zeros(1,8);

V(1, xoo) = A1;
V(1, oxo) = A1;
V(1, oox) = A1;

V(1, xxo) = A2;
V(1, xox) = A2;
V(1, oxx) = A2;

V(1, xxx) = A3;

T = sum(V(1, :));
V(1, ooo) = 1.0 - T;

end

