function Substrates = SetDefaultSubstrates(UseExactNA)

NA = 0.0;
if UseExactNA
    NA = Define13CNaturalAbundance();
end

% [o, x] = DefineOneCarbonLabelIndices();
% CO2 = zeros(1,2);
% CO2(1, o) = 1.0;
% Substrates.CO2 = CO2;
% 
% [oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
% FA = zeros(1,4);
% FA(1, oo) = 1.0;
% Substrates.FA = FA;

% [ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
%                                             DefineThreeCarbonLabelIndices();
% Lac = zeros(1,8);
% Lac(1, ooo) = 1.0;
% Substrates.Lac = Lac;
% 
% Substrates.Glyc = Lac;

% [oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
%  ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
%                                           DefineFourCarbonLabelIndices();
% SuccYs = zeros(1,16);
% SuccYs(1, oooo) = 1.0;
% Substrates.SuccYs = SuccYs;
% 
% [ooooo, xoooo, oxooo, xxooo, ...
%  ooxoo, xoxoo, oxxoo, xxxoo, ...
%  oooxo, xooxo, oxoxo, xxoxo, ...
%  ooxxo, xoxxo, oxxxo, xxxxo, ...
%  oooox, xooox, oxoox, xxoox, ...
%  ooxox, xoxox, oxxox, xxxox, ...
%  oooxx, xooxx, oxoxx, xxoxx, ...
%  ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();
% Gln = zeros(1,32);
% Gln(1, ooooo) = 1.0;
% Substrates.Gln = Gln;

CO2 = BuildOneCarbonNaturalAbundance(NA);
Substrates.CO2 = CO2;

FA = BuildTwoCarbonNaturalAbundance(NA);
Substrates.FA = FA;

Lac = BuildThreeCarbonNaturalAbundance(NA);
Substrates.Lac = Lac;
Substrates.Glyc = Lac;

SuccYs = BuildFourCarbonNaturalAbundance(NA);
Substrates.SuccYs = SuccYs;

Gln = BuildFiveCarbonNaturalAbundance(NA);
Substrates.Gln = Gln;

    
end

