function ReportGDAMMs(MMs, WDN)
nMMs = size(MMs, 2);
AICs = zeros(1, nMMs);
for i = 1:nMMs
    MM = MMs(1, i);
    AICs(1, i) = MM.AIC;
end
[AICs, idx] = sort(AICs);
MMs(1, :) = MMs(1, idx);
    
for i = 1:nMMs
    MM = MMs(1, i);
    if i == 1
       XIDs = MM.XIDs;
    else 
       XIDs = [XIDs, MM.XIDs];
    end
end

XIDs = unique(XIDs);
nXIDs = size(XIDs, 2);

TMM = MM(1);
GDA = TMM.GDA;
GD = GDA(1);
SID = GD.StudyID;
tcaCALCID = TMM.tcaCALCID;
tcaSIMID = TMM.tcaSIMID;

FN = [WDN, SID, '_ModelsResults.csv'];
fileID = fopen(FN, 'w');

WritePreambleTCAC(fileID, tcaSIMID, tcaCALCID, SID);

txt = 'Best fit results for each model\n';
fprintf(fileID, txt);

H = ['ExperimentID,', ...
     'ModelID,' ...
     'ln(Residual),', ...
     'DOF,', ...
     'ln(Likelihood),', ...
     'AIC,', ...
     'AICc,', ...
     'AndersonDarling h,', ...
     'AndersonDarling p,'];
T = '';
for i = 1:nXIDs
    ID = char(XIDs(1,i));
    T = [T, ID, ' BestFit,', ...
            ID, ' STD (covar),' ...
            ID, ' Start,', ...
            ID, ' LB,', ...
            ID, ' UB,'];
end
        
H = [H, T, 'ExitFlag,', ...    
           'nIter,', ...    
           'nSims,'];  
BestGDA = TMM.BestGDA;
nBestGDA = size(BestGDA, 2);
for i = 1:nBestGDA
    GD = BestGDA(1,i);
    ID = [GD.MolID, ' ', GD. MeasID];
    T = [ID, ' BestFit,'];
    H = [H, T];
    T = [ID, ' Meas,'];
    H = [H, T];
    T = [ID, ' Err'];
    H = [H, T];
    if i < nBestGDA
        H = [H, ','];
    end
    if i == nBestGDA
        H = [H, '\n'];
    end
end
    
fprintf(fileID, H);

for i = 1:nMMs
    MM = MMs(1, i);
    GDA = MM.GDA;
    GD = GDA(1, 1);
    MMXIDs = MM.XIDs;
    txt = [GD.StudyID, ',', ...
           MM.ExptID, ',', ...
           num2str(log(MM.BestEV)), ',', ...
           num2str(MM.DOF), ',', ...
           num2str(MM.LnL), ',', ...
           num2str(MM.AIC), ',', ...
           num2str(MM.AICc), ',', ...
           num2str(MM.ADh), ',', ...
           num2str(MM.ADp), ','];
     for j = 1:nXIDs
         XID = char(XIDs(1,j));
         U = strsplit(XID, ' ');
         nU = size(U, 2);
         if nU == 1
            txt = [txt, num2str(MM.(XID)), ','];
         end
         if nU == 2
            V = GetIsotopomerFromStruct(MM, XID);
            txt = [txt, num2str(V), ','];
         end
         Q = strcmp(MMXIDs, XID);
         if sum(Q) == 0
             txt = [txt,'NF,NF,NF,NF,'];
         else
             txt = [txt, num2str(MM.XSTDCovar(Q)), ','];
             txt = [txt, num2str(MM.XS(Q)), ','];          
             txt = [txt, num2str(MM.XSLB(Q)), ','];
             txt = [txt, num2str(MM.XSUB(Q)), ','];
         end
     end
     txt = [txt, num2str(MM.exitflag), ',']; 
     txt = [txt, num2str(MM.nIter), ',']; 
     txt = [txt, num2str(MM.nSims), ',']; 
     BestGDA = MM.BestGDA;
     nBestGDA = size(BestGDA, 2);
     GDA = MM.GDA;
     for k = 1:nBestGDA
         M = BestGDA(1,k);
         Z = GDA(1,k);
         E = Z.Value - M.Value;
         txt = [txt, num2str(M.Value), ',', ...
                     num2str(Z.Value), ',', ...
                     num2str(E)];
         if k < nBestGDA
            txt = [txt, ','];
         end
         if k == nBestGDA
            txt = [txt, '\n'];
         end
     end
     
     fprintf(fileID, txt);
end

txt = '\n\n\n';
fprintf(fileID, txt);

txt = ['AcetylCoA isotopomers calculated by non-steady state analysis ', ...
       '(Malloy etal Biochemistry. 1990 Jul 24;29(29):6756-61).\n'];
fprintf(fileID, txt);
txt = ['Requires user provided measures of Glu C4 to C3 Fractional ', ...
       'Enrichment Ratio and Glu Multiplets C4 D34 and C4 Q.\n']; 
fprintf(fileID, txt);
txt = ['Values equal to -1 indicate insufficient information has been ', ...
      'provided\n'];
fprintf(fileID, txt);
H = ['ExperimentID,ModelID,ExactNaturalAbundance,', ...
     'AcA oo,AcA xo,AcA ox,AcA xx\n'];
fprintf(fileID, H);
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
for i = 1:nMMs
    MM = MMs(1, i);
    GDA = MM.GDA;
    GD = GDA(1, 1);
    ENA = MM.ExactNaturalAbundance;
    AcA = EstimateAcAFromC4OverC3(GDA, ENA);
    txt = [GD.StudyID, ',', ...
           MM.ExptID, ',', ...
           num2str(ENA), ',', ...
           num2str(AcA(oo)), ',', ...
           num2str(AcA(xo)), ',', ...
           num2str(AcA(ox)), ',', ...
           num2str(AcA(xx)), '\n'];
    fprintf(fileID, txt);
end

txt = '\n\n\n';
fprintf(fileID, txt);

H = 'Best fit intermediate isotopomers at isotopic steady state\n';
fprintf(fileID, H);

H = 'ModelID,ExactNaturalAbundance,AcA oo,AcA xo,AcA ox,AcA xx\n';
fprintf(fileID, H);
for i = 1:nMMs
    MM = MMs(1, i);
    ENA = MM.ExactNaturalAbundance;
    LDH = MM.YPC + MM.PDH - MM.PK;
    if LDH < 0
        MM.PDH = MM.PDH - LDH; % hate doing this, but prevents crash when LDH is small and negative
    end
    [Isotops, VersionID] = ...
                        SimulateIsotopomers(MM.nTurns, ...
                        MM.GK, MM.PDH, MM.PK, MM.ROF, MM.RSM, MM.TPI, MM.YPC, MM.Ys, ...
                        MM.EaKG, MM.ECit, MM.EOAA, ...
                        MM.CO2, MM.FA, MM.Glc, MM.Glyc, MM.Lac, MM.SuccYs, ...
                        MM.ExactNaturalAbundance);
    AcA = Isotops.AcA;
    Sz = size(AcA);
    AcA = AcA(Sz(1), :);
    txt = [MM.ExptID, ',', ...
           num2str(ENA), ',', ...
           num2str(AcA(oo)), ',', ...
           num2str(AcA(xo)), ',', ...
           num2str(AcA(ox)), ',', ...
           num2str(AcA(xx)), '\n'];
           fprintf(fileID, txt);
end

txt = '\n\n\n';
fprintf(fileID, txt);

H = ['ModelID,ExactNaturalAbundance,', ...
     'Pyr ooo,', ...
     'Pyr xoo,', ...
     'Pyr oxo,', ...
     'Pyr xxo,', ...
     'Pyr oox,', ...
     'Pyr xox,', ...
     'Pyr oxx,', ...
     'Pyr xxx', '\n'];
fprintf(fileID, H);
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                          DefineThreeCarbonLabelIndices();
for i = 1:nMMs
    MM = MMs(1, i);
    ENA = MM.ExactNaturalAbundance;
    LDH = MM.YPC + MM.PDH - MM.PK;
    if LDH < 0
        MM.PDH = MM.PDH - LDH; % hate doing this, but prevents crash when LDH is small and negative
    end
    [Isotops, VersionID] = ...
                        SimulateIsotopomers(MM.nTurns, ...
                        MM.GK, MM.PDH, MM.PK, MM.ROF, MM.RSM, MM.TPI, MM.YPC, MM.Ys, ...
                        MM.EaKG, MM.ECit, MM.EOAA, ...
                        MM.CO2, MM.FA, MM.Glc, MM.Glyc, MM.Lac, MM.SuccYs, ...
                        MM.ExactNaturalAbundance);
    Pyr = Isotops.Pyr;
    Sz = size(Pyr);
    Pyr = Pyr(Sz(1), :);
    txt = [MM.ExptID, ',', ...
           num2str(ENA), ',', ...
           num2str(Pyr(ooo)), ',', ...
           num2str(Pyr(xoo)), ',', ...
           num2str(Pyr(oxo)), ',', ...
           num2str(Pyr(xxo)), ',', ...
           num2str(Pyr(oox)), ',', ...
           num2str(Pyr(xox)), ',', ...
           num2str(Pyr(oxx)), ',', ...
           num2str(Pyr(xxx)), '\n'];
           fprintf(fileID, txt);
end

txt = '\n\n\n';
fprintf(fileID, txt);

txt = ['Substrate isotopomers (includes best fit ', ...
       'substrate isotopomers when applicable)\n'];
fprintf(fileID, txt);

IsoIDs = {'FA oo', 'FA xo', 'FA ox', 'FA xx'};
DumpSubstrates(MMs, IsoIDs, fileID);

IsoIDs = {'CO2 o', 'CO2 x'};
DumpSubstrates(MMs, IsoIDs, fileID);

IsoIDs = {'Lac ooo', 'Lac xoo', 'Lac oxo', 'Lac xxo', ...
          'Lac oox', 'Lac xox', 'Lac oxx', 'Lac xxx'};
DumpSubstrates(MMs, IsoIDs, fileID);

IsoIDs = {'Glyc ooo', 'Glyc xoo', 'Glyc oxo', 'Glyc xxo', ...
          'Glyc oox', 'Glyc xox', 'Glyc oxx', 'Glyc xxx'};
DumpSubstrates(MMs, IsoIDs, fileID);

IsoIDs = {'SuccYs oooo', 'SuccYs xooo', 'SuccYs oxoo', 'SuccYs xxoo', ...
          'SuccYs ooxo', 'SuccYs xoxo', 'SuccYs oxxo', 'SuccYs xxxo', ...
          'SuccYs ooox', 'SuccYs xoox', 'SuccYs oxox', 'SuccYs xxox', ...
          'SuccYs ooxx', 'SuccYs xoxx', 'SuccYs oxxx', 'SuccYs xxxx'};
DumpSubstrates(MMs, IsoIDs, fileID);

IsoIDs = {'Gln ooooo', 'Gln xoooo', 'Gln oxooo', 'Gln xxooo', ...
          'Gln ooxoo', 'Gln xoxoo', 'Gln oxxoo', 'Gln xxxoo', ...
          'Gln oooxo', 'Gln xooxo', 'Gln oxoxo', 'Gln xxoxo', ...
          'Gln ooxxo', 'Gln xoxxo', 'Gln oxxxo', 'Gln xxxxo', ...
          'Gln oooox', 'Gln xooox', 'Gln oxoox', 'Gln xxoox', ...
          'Gln ooxox', 'Gln xoxox', 'Gln oxxox', 'Gln xxxox', ...
          'Gln oooxx', 'Gln xooxx', 'Gln oxoxx', 'Gln xxoxx', ...
          'Gln ooxxx', 'Gln xoxxx', 'Gln oxxxx', 'Gln xxxxx'};
DumpSubstrates(MMs, IsoIDs, fileID);

fclose(fileID);

end

function DumpSubstrates(MMs, IsoIDs, fileID)
nMMs = size(MMs, 2);
nIsoIDs = size(IsoIDs, 2);
H = 'ExperimentID,ModelID,ExactNaturalAbundance,';
for j = 1:nIsoIDs
    ID = char(IsoIDs(j));
    H = [H, ID, ','];
end
H = [H, '\n'];
fprintf(fileID, H);

for i = 1:nMMs
    MM = MMs(1, i);
    GDA = MM.GDA;
    GD = GDA(1, 1);
    txt = [GD.StudyID, ',', MM.ExptID, ','];
    txt = [txt, num2str(MM.ExactNaturalAbundance), ','];
    for j = 1:nIsoIDs
        ID = char(IsoIDs(j));
        V = GetIsotopomerFromStruct(MM, ID);
        txt = [txt, num2str(V), ','];
    end
    txt = [txt, '\n'];
    fprintf(fileID, txt);     
end
txt = '\n\n\n';
fprintf(fileID, txt);
end

