function MMs = ReadtcaCALCInputCSV(FN)
DUB = 1;
DLB = 0;

% FN = 'C:\Users\Jeffry R Alger\Desktop\TCACalcUpDateDraft\TestFolder\tcaSIMInput.csv';
ExptIDs = ReadFluxModels(FN, 'ExptID', 0);
nExpts = size(ExptIDs, 2);

[Ys, YsLB, YsUB] = GetStartParameterValues(ReadFluxModels(FN, 'Ys', 0));
[GK, GKLB, GKUB] = GetStartParameterValues(ReadFluxModels(FN, 'GK', 0));
% [GP, GPLB, GPUB] = GetStartParameterValues(ReadFluxModels(FN, 'GP', 0));
[YPC, YPCLB, YPCUB] = GetStartParameterValues(ReadFluxModels(FN, 'YPC', 0));
[PDH, PDHLB, PDHUB] = GetStartParameterValues(ReadFluxModels(FN, 'PDH', 0));
[PK, PKLB, PKUB] = GetStartParameterValues(ReadFluxModels(FN, 'PK', 0));
[ROF, ROFLB, ROFUB] = GetStartParameterValues(ReadFluxModels(FN, 'ROF', 0));
[RSM, RSMLB, RSMUB] = GetStartParameterValues(ReadFluxModels(FN, 'RSM', 0));
[TPI, TPILB, TPIUB] = GetStartParameterValues(ReadFluxModels(FN, 'TPI', 0));
[EaKG, EaKGLB, EaKGUB] = GetStartParameterValues(ReadFluxModels(FN, 'EaKG', 0));
[ECit, ECitLB, ECitUB] = GetStartParameterValues(ReadFluxModels(FN, 'ECit', 0));
[EOAA, EOAALB, EOAAUB] = GetStartParameterValues(ReadFluxModels(FN, 'EOAA', 0));

% NR conveys not relevant array for parameter not expected to have
% upper/lower bounds
[nTurns, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'nTurns', 0));
[ExactNA, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'ExactNA', 0));
[XTol, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'XTol', 0));
[FTol, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'FTol', 0));
[nIter, NR, NR] = GetStartParameterValues(ReadFluxModels(FN,'nIter', 0));
[nFEvs, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'nFEvs', 0));
[UseXform, NR, NR] = GetStartParameterValues(ReadFluxModels(FN, 'UseXform', 0));

XIDs = ReadFitIDs(FN);

% read input isotopmer information for Gln
[ooooo, xoooo, oxooo, xxooo, ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ooxxx, xoxxx, oxxxx, xxxxx] = ...
        DefineFiveCarbonLabelIndices();
Gln = zeros(32, nExpts);  
GlnLB = zeros(32, nExpts);  
GlnUB = zeros(32, nExpts);

[Gln(xoooo, :), GlnLB(xoooo, :), GlnUB(xoooo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xoooo', nExpts);
[Gln(oxooo, :), GlnLB(oxooo, :), GlnUB(oxooo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxooo', nExpts);
[Gln(xxooo, :), GlnLB(xxooo, :), GlnUB(xxooo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxooo', nExpts);
            
[Gln(ooxoo, :), GlnLB(ooxoo, :), GlnUB(ooxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'ooxoo', nExpts);
[Gln(xoxoo, :), GlnLB(xoxoo, :), GlnUB(xoxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xoxoo', nExpts);
[Gln(oxxoo, :), GlnLB(oxxoo, :), GlnUB(oxxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxxoo', nExpts);
[Gln(xxxoo, :), GlnLB(xxxoo, :), GlnUB(xxxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxxoo', nExpts);
            
[Gln(oooxo, :), GlnLB(oooxo, :), GlnUB(oooxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oooxo', nExpts);
[Gln(xooxo, :), GlnLB(xooxo, :), GlnUB(xooxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xooxo', nExpts);
[Gln(oxoxo, :), GlnLB(oxoxo, :), GlnUB(oxoxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxoxo', nExpts);
[Gln(xxoxo, :), GlnLB(xxoxo, :), GlnUB(xxoxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxoxo', nExpts);
            
[Gln(ooxxo, :), GlnLB(ooxxo, :), GlnUB(ooxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'ooxxo', nExpts);
[Gln(xoxxo, :), GlnLB(xoxxo, :), GlnUB(xoxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xoxxo', nExpts);
[Gln(oxxxo, :), GlnLB(oxxxo, :), GlnUB(oxxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxxxo', nExpts);
[Gln(xxxxo, :), GlnLB(xxxxo, :), GlnUB(xxxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxxxo', nExpts);
            
[Gln(oooox, :), GlnLB(oooox, :), GlnUB(oooox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oooox', nExpts);
[Gln(xooox, :), GlnLB(xooox, :), GlnUB(xooox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xooox', nExpts);
[Gln(oxoox, :), GlnLB(oxoox, :), GlnUB(oxoox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxoox', nExpts);
[Gln(xxoox, :), GlnLB(xxoox, :), GlnUB(xxoox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxoox', nExpts);
            
[Gln(ooxox, :), GlnLB(ooxox, :), GlnUB(ooxox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'ooxox', nExpts);
[Gln(xoxox, :), GlnLB(xoxox, :), GlnUB(xoxox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xoxox', nExpts);
[Gln(oxxox, :), GlnLB(oxxox, :), GlnUB(oxxox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxxox', nExpts);
[Gln(xxxox, :), GlnLB(xxxox, :), GlnUB(xxxox, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxxox', nExpts);
            
[Gln(oooxx, :), GlnLB(oooxx, :), GlnUB(oooxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oooxx', nExpts);
[Gln(xooxx, :), GlnLB(xooxx, :), GlnUB(xooxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xooxx', nExpts);
[Gln(oxoxx, :), GlnLB(oxoxx, :), GlnUB(oxoxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxoxx', nExpts);
[Gln(xxoxx, :), GlnLB(xxoxx, :), GlnUB(xxoxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxoxx', nExpts);
            
[Gln(ooxxx, :), GlnLB(ooxxx, :), GlnUB(ooxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'ooxxx', nExpts);
[Gln(xoxxx, :), GlnLB(xoxxx, :), GlnUB(xoxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xoxxx', nExpts);
[Gln(oxxxx, :), GlnLB(oxxxx, :), GlnUB(oxxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'oxxxx', nExpts);
[Gln(xxxxx, :), GlnLB(xxxxx, :), GlnUB(xxxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Gln', 'xxxxx', nExpts);

Gln = BuildIsotopomerInformation(Gln, ExactNA, 5, ooooo);
GlnLB(GlnLB == -1) = DLB;
GlnUB(GlnUB == -1) = DUB;

% read input isotopmer information for SuccYs
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();
SuccYs = zeros(16, nExpts);     
SuccYsLB = zeros(16, nExpts); 
SuccYsUB = zeros(16, nExpts); 

[SuccYs(xooo, :), SuccYsLB(xooo, :), SuccYsUB(xooo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xooo', nExpts);
[SuccYs(oxoo, :), SuccYsLB(oxoo, :), SuccYsUB(oxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'oxoo', nExpts);
[SuccYs(xxoo, :), SuccYsLB(xxoo, :), SuccYsUB(xxoo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xxoo', nExpts);
            
[SuccYs(ooxo, :), SuccYsLB(ooxo, :), SuccYsUB(ooxo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'ooxo', nExpts);
[SuccYs(xoxo, :), SuccYsLB(xoxo, :), SuccYsUB(xoxo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xoxo', nExpts);
[SuccYs(oxxo, :), SuccYsLB(oxxo, :), SuccYsUB(oxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'oxxo', nExpts);
[SuccYs(xxxo, :), SuccYsLB(xxxo, :), SuccYsUB(xxxo, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xxxo', nExpts);
            
[SuccYs(ooox, :), SuccYsLB(ooox, :), SuccYsUB(ooox, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'ooox', nExpts);
[SuccYs(xoox, :), SuccYsLB(xoox, :), SuccYsUB(xoox, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xoox', nExpts);
[SuccYs(oxox, :), SuccYsLB(oxox, :), SuccYsUB(oxox, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'oxox', nExpts);
[SuccYs(xxox, :), SuccYsLB(xxox, :), SuccYsUB(xxox, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xxox', nExpts);
            
[SuccYs(ooxx, :), SuccYsLB(ooxx, :), SuccYsUB(ooxx, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'ooxx', nExpts);
[SuccYs(xoxx, :), SuccYsLB(xoxx, :), SuccYsUB(xoxx, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xoxx', nExpts);
[SuccYs(oxxx, :), SuccYsLB(oxxx, :), SuccYsUB(oxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'oxxx', nExpts);
[SuccYs(xxxx, :), SuccYsLB(xxxx, :), SuccYsUB(xxxx, :)] = ...
                ReadLabelledSubstrate(FN, 'SuccYs', 'xxxx', nExpts);

SuccYs = BuildIsotopomerInformation(SuccYs, ExactNA, 4, oooo);
SuccYsLB(SuccYsLB == -1) = DLB;
SuccYsUB(SuccYsUB == -1) = DUB;

% read input isotopmer information for Glyc    
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                               DefineThreeCarbonLabelIndices();
Glyc = zeros(8, nExpts);   
GlycLB = zeros(8, nExpts); 
GlycUB = zeros(8, nExpts);

[Glyc(xoo, :), GlycLB(xoo, :), GlycUB(xoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'xoo', nExpts);
[Glyc(oxo, :), GlycLB(oxo, :), GlycUB(oxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'oxo', nExpts);
[Glyc(xxo, :), GlycLB(xxo, :), GlycUB(xxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'xxo', nExpts);
            
[Glyc(oox, :), GlycLB(oox, :), GlycUB(oox, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'oox', nExpts);
[Glyc(xox, :), GlycLB(xox, :), GlycUB(xox, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'xox', nExpts);
[Glyc(oxx, :), GlycLB(oxx, :), GlycUB(oxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'oxx', nExpts);
[Glyc(xxx, :), GlycLB(xxx, :), GlycUB(xxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Glyc', 'xxx', nExpts);
            
Glyc = BuildIsotopomerInformation(Glyc, ExactNA, 3, ooo);
GlycLB(GlycLB == -1) = DLB;
GlycUB(GlycUB == -1) = DUB;

% read input isotopmer information for Lac
Lac = zeros(8, nExpts);   
LacLB = zeros(8, nExpts);
LacUB = zeros(8, nExpts);

[Lac(xoo, :), LacLB(xoo, :), LacUB(xoo, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'xoo', nExpts);
[Lac(oxo, :), LacLB(oxo, :), LacUB(oxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'oxo', nExpts);
[Lac(xxo, :), LacLB(xxo, :), LacUB(xxo, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'xxo', nExpts);
            
[Lac(oox, :), LacLB(oox, :), LacUB(oox, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'oox', nExpts);
[Lac(xox, :), LacLB(xox, :), LacUB(xox, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'xox', nExpts);
[Lac(oxx, :), LacLB(oxx, :), LacUB(oxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'oxx', nExpts);
[Lac(xxx, :), LacLB(xxx, :), LacUB(xxx, :)] = ...
                ReadLabelledSubstrate(FN, 'Lac', 'xxx', nExpts);

Lac = BuildIsotopomerInformation(Lac, ExactNA, 3, ooo);
LacLB(LacLB == -1) = DLB;
LacUB(LacUB == -1) = DUB;

% read input isotopmer information for FA
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
FA = zeros(4, nExpts);   
FALB = zeros(4, nExpts);
FAUB = zeros(4, nExpts);

[FA(xo, :), FALB(xo, :), FAUB(xo, :)] = ...
                ReadLabelledSubstrate(FN, 'FA', 'xo', nExpts);
[FA(ox, :), FALB(ox, :), FAUB(ox, :)] = ...
                ReadLabelledSubstrate(FN, 'FA', 'ox', nExpts);
[FA(xx, :), FALB(xx, :), FAUB(xx, :)] = ...
                ReadLabelledSubstrate(FN, 'FA', 'xx', nExpts);

FA = BuildIsotopomerInformation(FA, ExactNA, 2, oo);            
FALB(FALB == -1) = DLB;
FAUB(FAUB == -1) = DUB;

% read input isotopmer information for CO2
CO2 = zeros(2, nExpts); 
[o, x] = DefineOneCarbonLabelIndices();
[CO2(x, :), CO2LB(x, :), CO2UB(x, :)] = ...
                ReadLabelledSubstrate(FN, 'CO2', 'x', nExpts);
            
CO2 = BuildIsotopomerInformation(CO2, ExactNA, 1, o);            
CO2LB(CO2LB == -1) = DLB;
CO2UB(CO2UB == -1) = DUB;

for i = 1:nExpts
    ExptID = char(ExptIDs(i));
    MM.ExptID = ExptID;
    MM.Ys = Ys(i);
    MM.YsUB = YsUB(i);
    MM.YsLB = YsLB(i);
    MM.GK = GK(i);
    MM.GKUB = GKUB(i);
    MM.GKLB = GKLB(i);
    MM.YPC = YPC(i);
    MM.YPCUB = YPCUB(i);
    MM.YPCLB = YPCLB(i);
    MM.PDH = PDH(i);
    MM.PDHUB = PDHUB(i);
    MM.PDHLB = PDHLB(i);
    MM.PK = PK(i);
    MM.PKUB = PKUB(i);
    MM.PKLB = PKLB(i);
    MM.ROF = ROF(i);
    MM.ROFUB = ROFUB(i);
    MM.ROFLB = ROFLB(i);
    MM.RSM = RSM(i);
    MM.RSMUB = RSMUB(i);
    MM.RSMLB = RSMLB(i);
    MM.TPI = TPI(i);
    MM.TPIUB = TPIUB(i);
    MM.TPILB = TPILB(i);
    MM.EaKG = EaKG(i);
    MM.EaKGUB = EaKGUB(i);
    MM.EaKGLB = EaKGLB(i);
    MM.ECit = ECit(i);
    MM.ECitUB = ECitUB(i);
    MM.ECitLB = ECitLB(i);
    MM.EOAA = EOAA(i);
    MM.EOAAUB = EOAAUB(i);
    MM.EOAALB = EOAALB(i);
    MM.nTurns = nTurns(i);
    MM.ExactNaturalAbundance = ExactNA(i);
    MM.XTol = XTol(i);
    MM.FTol = FTol(i);
    MM.nIter = nIter(i);
    MM.nFEvs = nFEvs(i);
    MM.UseXform = UseXform(i);
    for j = 1:nExpts
        A = XIDs(j);
        T = char(A.ExptID);
        if strcmp(T, ExptID)
            MM.XIDs = A.XIDs;
        end
    end
    MM.SuccYs = SuccYs(:, i);
    MM.SuccYsLB = SuccYsLB(:, i);
    MM.SuccYsUB = SuccYsUB(:, i);
    MM.Lac = Lac(:, i);
    MM.LacLB = LacLB(:, i);
    MM.LacUB = LacUB(:, i);
    MM.Glyc = Glyc(:, i);
    MM.GlycLB = GlycLB(:, i);
    MM.GlycUB = GlycUB(:, i);
    MM.FA = FA(:, i);
    MM.FALB = FALB(:, i);
    MM.FAUB = FAUB(:, i);
    MM.CO2 = CO2(:, i);
    MM.CO2LB = CO2LB(:, i);
    MM.CO2UB = CO2UB(:, i);
    MM.Gln = Gln(:, i);
    MM.GlnLB = GlnLB(:, i);
    MM.GlnUB = GlnUB(:, i);
    MMs(i) = MM;
end
% MM = MMs(1,1);
% disp(['MM.ExptID: ', MM.ExptID]);
% disp(['MM.XIDS: ', MM.XIDs]);
% disp(['MM.PDH: ', num2str(MM.PDH)]);
% disp(['MM.PDH: ', num2str(MM.PDHLB)]);
% disp(['MM.PDH: ', num2str(MM.PDHUB)]);
% disp(['MM.ROF: ', num2str(MM.ROF)]);
% disp(['MM.ROFLB: ', num2str(MM.ROFLB)]);
% disp(['MM.ROFUB: ', num2str(MM.ROFUB)]);
% disp(['MM.FA: ', num2str(transpose(MM.FA))]);
% disp(['MM.FALB: ', num2str(transpose(MM.FALB))]);
% disp(['MM.FAUB: ', num2str(transpose(MM.FAUB))]);
% disp(['MM.Lac: ', num2str(transpose(MM.Lac))]);
% disp(['MM.LacLB: ', num2str(transpose(MM.LacLB))]);
% disp(['MM.LacUB: ', num2str(transpose(MM.LacUB))]);
end


% Helper function to streamline code
% builds the isotopomer information
function V = BuildIsotopomerInformation(V, ExactNA, nCarbon, E1)
nExpts = size(V, 2);
VNA = V*0.0;
if nCarbon == 1
    NA = BuildOneCarbonNaturalAbundance(Define13CNaturalAbundance());
end
if nCarbon == 2
    NA = BuildTwoCarbonNaturalAbundance(Define13CNaturalAbundance());
end
if nCarbon == 3
    NA = BuildThreeCarbonNaturalAbundance(Define13CNaturalAbundance());
end
if nCarbon == 4
    NA = BuildFourCarbonNaturalAbundance(Define13CNaturalAbundance());
end
if nCarbon == 5
    NA = BuildFiveCarbonNaturalAbundance(Define13CNaturalAbundance());
end
if nCarbon == 6
    NA = BuildSixCarbonNaturalAbundance(Define13CNaturalAbundance());
end

for i = 1:nExpts
    if ExactNA(i) == 1
        VNA(:, i) = NA;
    end
end

V(V == -1) = VNA(V == -1);
for i = 1:nExpts
    S = sum(V(:, i));
    V(E1, i) = 1.0 - S;
end

end
