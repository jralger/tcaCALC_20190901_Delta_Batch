function F = CombineFiveLabelPools(A, B, C, D, E, m, RA, RB, RC, RD)
% This function combines five different molecules (A through E)
% each of A through E is float(nTCATurns, nIsotopomers)
% where 
% nTCATurns is the number of TCA turns being simulated by the calling
% program
% nIsotopomers is the total number of isotopomers 
% eg Glu = float(35, 64) for a 35 TCA turn simulations
% m is the tTCA cycle turn number
% RA - RD are the proportions A - D contributes to the final mixture
% RE is computed (RA + RB + RC + RD + RE = 1.0)
% returns the weighted average of the five molecules

% note that this function does not check that the dimensions of the input
% molecules are matched. Error will occur if they are not matched.

RE = 1.0 - RA - RB - RC - RD;

F = D;
F(m, :) = (RA*A(m, :)) + ...
          (RB*B(m, :)) + ...
          (RC*C(m, :)) + ...
          (RD*D(m, :)) + ...
          (RE*E(m, :));
end

