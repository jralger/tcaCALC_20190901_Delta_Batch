function varargout = InputFiveCarbonIsotopomers(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InputFiveCarbonIsotopomers_OpeningFcn, ...
                   'gui_OutputFcn',  @InputFiveCarbonIsotopomers_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
         V = str2double(get(hObject,'String'));
         if V < 0
             hObject.String = ['0'];
         end
         
function hObject = CheckFixGTOne(hObject)
         V = str2double(get(hObject,'String'));
         if V > 1.0
             hObject.String = ['1'];
         end

function InputFiveCarbonIsotopomers_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
A = zeros(1,32);
MolID = char(varargin(2));
A = cell2mat(varargin(3));
Z = handles.MoleculeID;
Z.String = MolID;
handles.MoleculeID = Z;

[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

handles.OOOOO.String = sprintf('%4.2f',A(1, ooooo));
handles.XOOOO.String = sprintf('%4.2f',A(1, xoooo));
handles.OXOOO.String = sprintf('%4.2f',A(1, oxooo));
handles.XXOOO.String = sprintf('%4.2f',A(1, xxooo));

handles.OOXOO.String = sprintf('%4.2f',A(1, ooxoo));
handles.XOXOO.String = sprintf('%4.2f',A(1, xoxoo));
handles.OXXOO.String = sprintf('%4.2f',A(1, oxxoo));
handles.XXXOO.String = sprintf('%4.2f',A(1, xxxoo));

handles.OOOXO.String = sprintf('%4.2f',A(1, oooxo));
handles.XOOXO.String = sprintf('%4.2f',A(1, xooxo));
handles.OXOXO.String = sprintf('%4.2f',A(1, oxoxo));
handles.XXOXO.String = sprintf('%4.2f',A(1, xxoxo));

handles.OOXXO.String = sprintf('%4.2f',A(1, ooxxo));
handles.XOXXO.String = sprintf('%4.2f',A(1, xoxxo));
handles.OXXXO.String = sprintf('%4.2f',A(1, oxxxo));
handles.XXXXO.String = sprintf('%4.2f',A(1, xxxxo));

handles.OOOOX.String = sprintf('%4.2f',A(1, oooox));
handles.XOOOX.String = sprintf('%4.2f',A(1, xooox));
handles.OXOOX.String = sprintf('%4.2f',A(1, oxoox));
handles.XXOOX.String = sprintf('%4.2f',A(1, xxoox));

handles.OOXOX.String = sprintf('%4.2f',A(1, ooxox));
handles.XOXOX.String = sprintf('%4.2f',A(1, xoxox));
handles.OXXOX.String = sprintf('%4.2f',A(1, oxxox));
handles.XXXOX.String = sprintf('%4.2f',A(1, xxxox));

handles.OOOXX.String = sprintf('%4.2f',A(1, oooxx));
handles.XOOXX.String = sprintf('%4.2f',A(1, xooxx));
handles.OXOXX.String = sprintf('%4.2f',A(1, oxoxx));
handles.XXOXX.String = sprintf('%4.2f',A(1, xxoxx));

handles.OOXXX.String = sprintf('%4.2f',A(1, ooxxx));
handles.XOXXX.String = sprintf('%4.2f',A(1, xoxxx));
handles.OXXXX.String = sprintf('%4.2f',A(1, oxxxx));
handles.XXXXX.String = sprintf('%4.2f',A(1, xxxxx));

[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);

guidata(hObject, handles);
uiwait(handles.figure1);



function varargout = InputFiveCarbonIsotopomers_OutputFcn(hObject, eventdata, handles)
[handles, A] =  ReadUpdateAllFiveCarbonIsotopomers(handles);
varargout{1} = A;
close();


function pushbutton1_Callback(hObject, eventdata, handles)
[handles, A] =  ReadUpdateAllFiveCarbonIsotopomers(handles);
uiresume;


function OOOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OOXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OOXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OOXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OOXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XOXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function OXXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function XXXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOOOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function XOOOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXOOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXOOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOXOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XOXOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXXOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXXOO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOOXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XOOXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXOXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXOXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOXXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XOXXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXXXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXXXO_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOOOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XOOOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXOOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function XXOOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOXOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function XOXOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function OXXOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function XXXOX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOOXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function XOOXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);



function OXOXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXOXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OOXXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XOXXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function OXXXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);


function XXXXX_Callback(hObject, eventdata, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles);
guidata(hObject, handles);
