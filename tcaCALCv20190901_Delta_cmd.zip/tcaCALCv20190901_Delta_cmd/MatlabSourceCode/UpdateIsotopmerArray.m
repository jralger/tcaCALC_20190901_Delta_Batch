function A = UpdateIsotopmerArray(A, ID, V)
nA = size(A, 1);
TIDs = BuildIsotopomerIDs(nA);
for j = 1:nA
    T = char(TIDs(1, j));
    if strcmp(T, ID)
        A(j, 1) = V;
    end
end
A = UpdateNoLabelIsotopomer(A);




