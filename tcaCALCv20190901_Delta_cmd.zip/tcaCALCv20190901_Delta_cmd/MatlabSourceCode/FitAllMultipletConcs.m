function BestFitMolecules = FitAllMultipletConcs(Spectrum, ... 
                               Molecules, MinPPMWidth)
% uIDs1 = GetUniqueMoleculeIDs(Molecules);
nMols = size(Molecules, 1);
uIDs = GetUniqueCarbonIDs(Molecules);
nIDs = size(uIDs,2);
BestFitMolecules = Molecules;
S = 1;
h = waitbar(0, 'Please wait: Final stage of multiplet fitting is in progress');
for i = 1:nIDs
    TID = uIDs(i);
    RMols = IsolateMoleculesByCarbonID(Molecules, TID);
    RMols = FitMultipletSetConcs(Spectrum, ... 
                               RMols, MinPPMWidth);
    nRMols = size(RMols,1);
    E = S + nRMols - 1;
    BestFitMolecules(S:E) = RMols;
    S = E + 1;
    waitbar(i/nIDs);
end  
close(h);
% uIDs2 = GetUniqueMoleculeIDs(BestFitMolecules); 
% dummy = 1;
end


