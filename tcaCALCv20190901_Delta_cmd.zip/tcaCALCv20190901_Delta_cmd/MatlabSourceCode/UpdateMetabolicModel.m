function NMM = UpdateMetabolicModel(MM, X, XIDs)

% TX = X;
% TXIDs = XIDs;

if MM.UseXform
    PDH = MM.PDH;
    YPC = MM.YPC;
    Ys = MM.Ys;
    PK = MM.PK;

    Q = sum(strcmp(XIDs, 'x'));
    if Q
        x = X(strcmp(XIDs, 'x'));
        PDH = x;
        X(strcmp(XIDs, 'x')) = PDH;
        XIDs(strcmp(XIDs, 'x')) = {'PDH'};
    end

    Q = sum(strcmp(XIDs, 'y'));
    if Q
        y = X(strcmp(XIDs, 'y'));
%         disp(['y: ', num2str(y)])
        YPC = y/(1-y);
        X(strcmp(XIDs, 'y')) = YPC;
        XIDs(strcmp(XIDs, 'y')) = {'YPC'};
    end

    Q = sum(strcmp(XIDs, 'w'));
    if Q
        w = X(strcmp(XIDs, 'w'));
        Ys = w/(1-w);
        X(strcmp(XIDs, 'w')) = Ys;
        XIDs(strcmp(XIDs, 'w')) = {'Ys'};
    end

    Q = sum(strcmp(XIDs, 'z'));
    if Q
        z = X(strcmp(XIDs, 'z'));
        PK = z*(PDH + YPC);
        X(strcmp(XIDs, 'z')) = PK;
        XIDs(strcmp(XIDs, 'z')) = {'PK'};
    end
end



NMM = MM;

nX = size(X);
nX = nX(2);
for i = 1:nX
    ID = char(XIDs(1, i));
    ID = strsplit(ID, ' ');
    ID1 = char(ID(1));
    nID = size(ID); 
    nID = nID(2);
    if nID == 2
        ID2 = char(ID(2));
    end
    V = X(1, i);
    switch ID1
        case 'nTurns'
            NMM.nTurns = V;
        case 'GK'
            NMM.GK = V;
        case 'PDH'
            NMM.PDH = V;
        case 'PK'
            NMM.PK = V;
        case 'ROF'
            NMM.ROF = V;
        case 'RSM'
            NMM.RSM = V;
        case 'TPI'
            NMM.TPI = V;
        case 'YPC'
            NMM.YPC = V;
        case 'Ys'
            NMM.Ys = V;
        case 'EaKG'
            NMM.EaKG = V;
        case 'ECit'
            ECit = V;
        case 'EOAA'
            EOAA = V;
        case 'Lac'
            NMM.Lac = UpdateIsotopmerArray(NMM.Lac, ID2, V);
        case 'Glyc'
            NMM.Glyc = UpdateIsotopmerArray(NMM.Glyc, ID2, V);
        case 'FA'
            NMM.FA = UpdateIsotopmerArray(NMM.FA, ID2, V);
        case 'SuccYs'
            NMM.SuccYs = UpdateIsotopmerArray(NMM.SuccYs, ID2, V);
        case 'CO2'
            NMM.CO2 = UpdateIsotopmerArray(NMM.CO2, ID2, V);
    end
end
% X = TX;
% XIDs = TXIDs;
end

