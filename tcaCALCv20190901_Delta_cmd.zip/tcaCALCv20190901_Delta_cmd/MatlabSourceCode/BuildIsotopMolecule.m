function Molecule = BuildIsotopMolecule(LabelPattern, FreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, ScannerFreqMHz, ...
                      SampleTimesSec, CenterPPM)
% GlobalR2 = 5.0;
GlobalPhaseDeg = 0.0;
GlobalImagSign = '+';
GlobalSignalShape = 'Lorentz';
GlobalShapeParams = [GlobalR2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0];
GlobalSignalAmplitude = 1.0;
DefaultMolConc = 1.0;
DefaultR1SatFactor = 1.0;
                 
nCs = size(LabelPattern, 2);
nMolSignals = 0;
for i = 1:nCs
    if LabelPattern(i) == '1'
        Signals.FreqPPM = FreqsPPM(i);
        Signals.Amplitude = GlobalSignalAmplitude;
        Signals.PhaseDeg = GlobalPhaseDeg;
        Signals.Shape = GlobalSignalShape;
        Signals.ShapeParams = GlobalShapeParams;
        Signals.ImagSign = GlobalImagSign;
        Signals.ID = [' C', num2str(i)];
        for j = 1:nCs
            if j ~= i && JAPPM(i,j) ~= 0.0 && LabelPattern(j) == '1'
                Signals = MakeDoublets(Signals, JAPPM(i,j));
            end
        end
        if nMolSignals == 0
           MolSignals = Signals;
           nMolSignals = nMolSignals + 1;
           Signals = Signals(1);
        else
           MolSignals = [MolSignals, Signals];
           nMolSignals = nMolSignals + 1;
           Signals = Signals(1);
        end
    end
end
        
Molecule.Signals = MolSignals;
Molecule.FreqsPPM = FreqsPPM;
Molecule.JAPPM = JAPPM;
Molecule.LabelPattern = LabelPattern; 

txt = '';
for i = 1:nCs
    if LabelPattern(i) == '1'
       txt = [txt, 'C', num2str(i)];
    end
end
Molecule.ID = txt;

Molecule.Conc = MolConc;

R1SatFactors = FreqsPPM * 0.0;
R1SatFactors(:) = DefaultR1SatFactor;
Molecule.R1SatFactors = R1SatFactors;

Molecule = SimulateMoleculeSpectrum(Molecule, ScannerFreqMHz, ...
                    SampleTimesSec, CenterPPM, GlobalImagSign);    
Molecule.PlotCenters = FreqsPPM;
end

