function UserFreqsPPM = GetFreqsFromUser(handles, fig, FreqsPPM, FreqIDs)
UserFreqsPPM = FreqsPPM;
% dcm_obj = datacursormode(fig);
% set(dcm_obj,'DisplayStyle','datatip',...
%     'SnapToDataVertex','off','Enable','on');
nFreqs = size(FreqIDs, 2);
for i = 1:nFreqs
    txt = FreqIDs(i);
    txt = txt(1);
    txt = char(txt);
%     T = ': Click on signal and press return';
    T = ': Move crosshairs to signal maximum and left click';
    txt = [txt T] ;
    handles.UserInstruct.String = txt;
%     disp(txt);
%     pause;
%     c_info = getCursorInfo(dcm_obj);
%     ClickedPPM = c_info.Position;
%     ClickedPPM = ClickedPPM(1);
    [ClickedPPM, y] = ginput(1);
    UserFreqsPPM(i) = ClickedPPM;
end
txt = 'Select another multiplet or Select Fit Multiplets';
handles.UserInstruct.String = txt;
end

