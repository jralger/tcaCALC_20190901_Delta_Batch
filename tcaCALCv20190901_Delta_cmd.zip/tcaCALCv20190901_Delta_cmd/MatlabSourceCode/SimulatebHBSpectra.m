function Molecules = SimulatebHBSpectra(Molecules, V)

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();

nMols = size(Molecules, 2);

FE = GetFractionalEnrichment(V);

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    
    if strcmp(ID, 'bHB C1 S')
      Conc = V(xooo) + V(xoxo) + V(xoox) + V(xoxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C1 D')
      Conc = V(xxoo) + V(xxxo) + V(xxox) + V(xxxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C2 S')
      Conc = V(oxoo) + V(oxox);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C2 D12')
      Conc = V(xxoo) + V(xxox);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C2 D23')
      Conc = V(oxxo) + V(oxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C2 Q')
      Conc = V(xxxo) + V(xxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C3 S')
      Conc = V(ooxo) + V(xoxo);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
%     if strcmp(ID, 'bHB C3 D23')
%       Conc = V(oxxo) + V(xxxo);
%       Mol.Conc = Conc;
%       TotConc = FE(3);
%       if TotConc ~= 0.0
%           Mol.RelConc = Conc/TotConc;
%       end
%       Molecules(1, i) = Mol;
%     end
%     
%     if strcmp(ID, 'bHB C3 D34')
%       Conc = V(ooxx) + V(xoxx);
%       Mol.Conc = Conc;
%       TotConc = FE(3);
%       if TotConc ~= 0.0
%           Mol.RelConc = Conc/TotConc;
%       end
%       Molecules(1, i) = Mol;
%     end
%     
%     if strcmp(ID, 'bHB C3 Q')
%       Conc = V(oxxx) + V(xxxx);
%       Mol.Conc = Conc;
%       TotConc = FE(3);
%       if TotConc ~= 0.0
%           Mol.RelConc = Conc/TotConc;
%       end

    if strcmp(ID, 'bHB C3 D')
      Conc = V(oxxo) + V(xxxo) + V(ooxx) + V(xoxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C3 T')
      Conc = V(oxxx) + V(xxxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end



      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C4 S')
      Conc = V(ooox) + V(xoox) + V(oxox) + V(xxox);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'bHB C4 D')
      Conc = V(ooxx) + V(xoxx) + V(oxxx) + V(xxxx);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
end

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if contains(ID, 'bHB')
        NS = Mol.NormSpectrum;
        FD = NS.FreqDomainData;
        Conc = Mol.Conc;
        FD = FD*Conc;
        CWS = Mol.ConcWtdSpectrum;
        CWS.FreqDomainData = FD;
        Mol.ConcWtdSpectrum = CWS;
        Molecules(1, i) = Mol;
    end
end

% for i = 1:nMols
%     Mol = Molecules(1, i);
%     Conc = Mol.Conc
% end

end

