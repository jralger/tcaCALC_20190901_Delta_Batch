function C = CombineTwoLabelPools(A, B, m, RA)
% This function combines two different molecules (A and B)
% each of A and B is float(nTCATurns, nIsotopomers)
% where 
% nTCATurns is the number of TCA turns being simulated by the calling
% program
% nIsotopomers is the total number of isotopomers 
% eg Glu = float(35, 64) for a 35 TCA turn simulation
% m is the TCA cycle turn number
% RA is the proportion A contributes to the final mixture
% RB is computed (RA + RB  = 1.0)
% returns the weighted average of the two molecules

% note that this function does not check that the dimensions of the input
% molecules are matched. Error will occur if they are not matched.

C = B;
RB = 1.0 - RA;
C(m, :) = (RA*A(m,:)) + (RB*B(m,:));
end

