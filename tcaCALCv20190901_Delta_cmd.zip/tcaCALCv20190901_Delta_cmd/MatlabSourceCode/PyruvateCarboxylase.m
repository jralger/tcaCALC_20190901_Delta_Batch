function OAA_PC = PyruvateCarboxylase(Pyr, CO2, OAA, m)

%Pyr + CO2 ---> OAA
% pyr C1 --> OAA C1
% pyr C2 --> OAA C2
% pyr C3 --> OAA C3
% CO2 --> OAA C4


[o, x] = DefineOneCarbonLabelIndices();

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
                                
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                    DefineFourCarbonLabelIndices();
                                
 OAA_PC = OAA;
                                
 OAA_PC(m, oooo) = Pyr(m, ooo) * CO2(m, o);
 OAA_PC(m, xooo) = Pyr(m, xoo) * CO2(m, o);
 OAA_PC(m, oxoo) = Pyr(m, oxo) * CO2(m, o);
 OAA_PC(m, xxoo) = Pyr(m, xxo) * CO2(m, o);
 
 OAA_PC(m, ooxo) = Pyr(m, oox) * CO2(m, o);
 OAA_PC(m, xoxo) = Pyr(m, xox) * CO2(m, o);
 OAA_PC(m, oxxo) = Pyr(m, oxx) * CO2(m, o);
 OAA_PC(m, xxxo) = Pyr(m, xxx) * CO2(m, o);
 
 OAA_PC(m, ooox) = Pyr(m, ooo) * CO2(m, x);
 OAA_PC(m, xoox) = Pyr(m, xoo) * CO2(m, x);
 OAA_PC(m, oxox) = Pyr(m, oxo) * CO2(m, x);
 OAA_PC(m, xxox) = Pyr(m, xxo) * CO2(m, x);
 
 OAA_PC(m, ooxx) = Pyr(m, oox) * CO2(m, x);
 OAA_PC(m, xoxx) = Pyr(m, xox) * CO2(m, x);
 OAA_PC(m, oxxx) = Pyr(m, oxx) * CO2(m, x);
 OAA_PC(m, xxxx) = Pyr(m, xxx) * CO2(m, x);

end

