function Multiplets = BuildAlaDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
FreqsPPM = R.AlaEstFreqsPPM;

R = SetDefaultJs();
JAHz = R.AlaEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'Ala C1 S';
FreqPPM = FreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: Ala C1 S
              Multiplet, ...  %2: Ala C1 D
              Multiplet, ...  %3: Ala C2 S
              Multiplet, ...  %4: Ala C2 D12
              Multiplet, ...  %5: Ala C2 D23
              Multiplet, ...  %6: Ala C2 Q
              Multiplet, ...  %7: Ala C3 S
              Multiplet];     %8: Ala C3 D
n = 2;

ID = 'Ala C1 D';
FreqPPM = FreqsPPM(1);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C2 S';
FreqPPM = FreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C2 D12';
FreqPPM = FreqsPPM(2);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C2 D23';
FreqPPM = FreqsPPM(2);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C2 Q';
FreqPPM = FreqsPPM(2);
JHz = [JAHz(1,2), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C3 S';
FreqPPM = FreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Ala C3 D';
FreqPPM = FreqsPPM(3);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;


end

