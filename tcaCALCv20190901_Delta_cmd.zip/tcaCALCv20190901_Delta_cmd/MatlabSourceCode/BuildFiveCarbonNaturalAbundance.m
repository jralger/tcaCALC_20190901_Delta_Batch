function V = BuildFiveCarbonNaturalAbundance(A)

[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

A1 = A;
A2 = A*A;
A3 = A*A*A;
A4 = A*A*A*A;
A5 = A*A*A*A*A;

V = zeros(1,32);

V(1, xoooo) = A1;
V(1, oxooo) = A1;
V(1, xxooo) = A2;

V(1, ooxoo) = A1;
V(1, xoxoo) = A2;
V(1, oxxoo) = A2;
V(1, xxxoo) = A3;

V(1, oooxo) = A1;
V(1, xooxo) = A2;
V(1, oxoxo) = A2;
V(1, xxoxo) = A3;

V(1, ooxxo) = A2;
V(1, xoxxo) = A3;
V(1, oxxxo) = A3;
V(1, xxxxo) = A4;

V(1, oooox) = A1;
V(1, xooox) = A2;
V(1, oxoox) = A2;
V(1, xxoox) = A3;

V(1, ooxox) = A2;
V(1, xoxox) = A3;
V(1, oxxox) = A3;
V(1, xxxox) = A4;

V(1, oooxx) = A2;
V(1, xooxx) = A3;
V(1, oxoxx) = A3;
V(1, xxoxx) = A4;

V(1, ooxxx) = A3;
V(1, xoxxx) = A4;
V(1, oxxxx) = A4;
V(1, xxxxx) = A5;

T = sum(V(1,:));
V(1, ooooo) = 1.0 - T;
                    
end

