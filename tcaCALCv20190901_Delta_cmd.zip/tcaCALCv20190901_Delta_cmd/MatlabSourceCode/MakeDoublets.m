function RSignals = MakeDoublets(Signals, JPPM)

if JPPM == 0.0
    RSignals = Signals;
end

if JPPM > 0.0
    nSignals = size(Signals,2);
    for i=1:nSignals;
        Signal = Signals(1,i);
        F = Signal.FreqPPM;
        A = Signal.Amplitude;
        SignalA = Signal;
        SignalB = Signal;
        SignalA.FreqPPM = F + JPPM/2.0;
        SignalB.FreqPPM = F - JPPM/2.0;
        SignalA.Amplitude = A/2.0;
        SignalB.Amplitude = A/2.0;
        if i == 1
            RSignals = [SignalA, SignalB];
        end
        if i > 1
            RSignals = [RSignals, SignalA, SignalB];
        end
    end
end

end

