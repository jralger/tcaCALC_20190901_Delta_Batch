function Succ_RSM = RandomizeSuccinate(Succ, m, R)
% R = 0.0: Complete flip (all C1 becomes C4 etc)
% R = 0.5: Complete scambling (C1 has 50% chance of labelling C4)
% R = 1: No scambling

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx , oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();

if R > 1.0
    R = 1.0;
end

if R < 0.0
    R = 0.0
end
                                                                       
A = R;
B = 1.0 - R;
Succ_RSM = Succ;

Succ_RSM(m, oooo) = (A*Succ(m, oooo)) + (B*Succ(m, oooo));
Succ_RSM(m, xooo) = (A*Succ(m, xooo)) + (B*Succ(m, ooox));
Succ_RSM(m, oxoo) = (A*Succ(m, oxoo)) + (B*Succ(m, ooxo));
Succ_RSM(m, xxoo) = (A*Succ(m, xxoo)) + (B*Succ(m, ooxx));

Succ_RSM(m, ooxo) = (A*Succ(m, ooxo)) + (B*Succ(m, oxoo));
Succ_RSM(m, xoxo) = (A*Succ(m, xoxo)) + (B*Succ(m, oxox));
Succ_RSM(m, oxxo) = (A*Succ(m, oxxo)) + (B*Succ(m, oxxo));
Succ_RSM(m, xxxo) = (A*Succ(m, xxxo)) + (B*Succ(m, oxxx));

Succ_RSM(m, ooox) = (A*Succ(m, ooox)) + (B*Succ(m, xooo));
Succ_RSM(m, xoox) = (A*Succ(m, xoox)) + (B*Succ(m, xoox));
Succ_RSM(m, oxox) = (A*Succ(m, oxox)) + (B*Succ(m, xoxo));
Succ_RSM(m, xxox) = (A*Succ(m, xxox)) + (B*Succ(m, xoxx));

Succ_RSM(m, ooxx) = (A*Succ(m, ooxx)) + (B*Succ(m, xxoo));
Succ_RSM(m, xoxx) = (A*Succ(m, xoxx)) + (B*Succ(m, xxox));
Succ_RSM(m, oxxx) = (A*Succ(m, oxxx)) + (B*Succ(m, xxxo));
Succ_RSM(m, xxxx) = (A*Succ(m, xxxx)) + (B*Succ(m, xxxx));

end

