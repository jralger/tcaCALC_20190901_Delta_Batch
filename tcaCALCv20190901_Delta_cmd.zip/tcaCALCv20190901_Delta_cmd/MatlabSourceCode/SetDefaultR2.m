function R2 = SetDefaultR2()
R2 = 5.0;
end

