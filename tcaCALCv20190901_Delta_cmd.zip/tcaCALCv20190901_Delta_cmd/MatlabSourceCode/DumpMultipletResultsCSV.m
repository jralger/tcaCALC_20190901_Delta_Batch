function DumpMultipletResultsCSV(Molecules, DN)

% FN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\OutputBMPs\MultipletResults.csv';
FN = [DN, '\', 'MultipletResults.csv'];
fileID = fopen(FN, 'w');

txt = 'C13 NMR Isotopomer Multiplet Analysis 0\n';
fprintf(fileID, txt);

txt = 'Copyright: 2017 UTSouthwestern Advanced Imaging Research Center\n';
fprintf(fileID, txt);

txt = 'Design by NeuroSpectroScopics LLC\n';
fprintf(fileID, txt);

txt = 'www.neurospectroscopics.com\n';
fprintf(fileID, txt);

txt1 = 'Acknowledgement for publications: ';
txt2 = 'Development of C13 NMR Isotopomer Multiplet Analysis ';
txt3 = 'was supported by funding from NIH/NIBIB P41 EB015908\n ';
txt = [txt1, txt2, txt3];
fprintf(fileID, txt);

txt = 'NOT FOR CLINICAL USE\n';
fprintf(fileID, txt);

% txt = datetime('now');
% fmt = 'dd-MMM-yyyy HH:mm:ss z';
% fprintf(fileID, fmt, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

H1 = 'SpectrumID,MultipletID,FractionalIntensityBestFit,';
H2 = 'FractionalIntegralBestFit,RawIntensityBestFit,';
H3 = 'MultipletCenterPPM,IsotopeShift,LorentzR2*(sec-1),R1SatFactor,';
H4 = 'JHz(1_2),JHz(1_3),JHz(1_4),JHz(1_5),JHz(1_6),';
H5 = 'JHz(2_3),JHz(2_4),JHz(2_5),JHz(2_6),';
H6 = 'JHz(3_4),JHz(3_5),JHz(3_6),';
H7 = 'JHz(4_5),JHz(4_6),';
H8 = 'JHz(5_6),';
H9 = '\n';
H = [H1, H2, H3, H4, H5, H6, H7, H8, H9];
fprintf(fileID, H);

SpectrumID = 'Unspecified';

nM = size(Molecules, 1);
for i =1:nM
    txt = [SpectrumID, ','];
    Molecule = Molecules(i);
    txt = [txt, Molecule.ID, ','];
    txt = [txt, num2str(Molecule.FractionalConc), ','];
    txt = [txt, num2str(Molecule.FractionalIntegral), ','];
    txt = [txt, num2str(Molecule.Conc), ','];
    txt = [txt, num2str(Molecule.PlotCenters), ','];
    txt = [txt, 'N/A', ','];
    Signals = Molecule.Signals;
    Signal = Signals(1);
    ShapeParams = Signal.ShapeParams;
    R2 = ShapeParams(1);
    txt = [txt, num2str(R2), ','];
    txt = [txt, 'N/A', ','];
    
    sf = str2num(Molecule.ScannerFreqMHz);
    JAHz = Molecule.JAPPM*sf;
    JAHzp = zeros(6);
    nJ = size(JAHz,1);
    JAHzp(1:nJ, 1:nJ) = JAHz;
    for l = 1:6
        for m = 1:6
            if l < m
               if JAHzp(l,m) ~= 0.0
                  txt = [txt, num2str(JAHzp(l,m)), ','];
               else 
                  txt = [txt, 'N/A', ','];
               end
            end
        end
    end
    txt = [txt, '\n'];
    fprintf(fileID, txt);
end
    
fclose(fileID);
end

