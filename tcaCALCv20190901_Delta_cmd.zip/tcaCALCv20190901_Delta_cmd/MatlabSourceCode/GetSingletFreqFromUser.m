function FreqPPM = GetSingletFreqFromUser(handles, Spectrum, ax, fig, EstimatedFreqPPM, DisplayPPMWidth, SingletID)
FreqPPM = EstimatedFreqPPM;
PPMLow = EstimatedFreqPPM - (DisplayPPMWidth/2.0);
PPMHigh = EstimatedFreqPPM + (DisplayPPMWidth/2.0);
FreqIDs = {SingletID};
ax = DisplayReferencedSubSPectrum(Spectrum, ax, [EstimatedFreqPPM], PPMLow, PPMHigh);
FreqPPM = GetFreqsFromUser(handles, fig, [EstimatedFreqPPM], FreqIDs);
% ax = DisplayReferencedSubSPectrum(Spectrum, ax, FreqPPM, PPMLow, PPMHigh);
end

