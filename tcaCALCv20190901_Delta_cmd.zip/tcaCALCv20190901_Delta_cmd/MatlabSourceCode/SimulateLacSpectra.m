function Molecules = SimulateLacSpectra(Molecules, V)

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();

nMols = size(Molecules, 2);
Mol = Molecules(1, 1);

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if strcmp(ID, 'Lac C1 S')
      Conc = V(xoo) + V(xox);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C1 D')
      Conc = V(xxo) + V(xxx);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C2 S')
      Conc = V(oxo);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C2 D12')
      Conc = V(xxo);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C2 D23')
      Conc =  V(oxx);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C2 Q')
      Conc = V(xxx);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C3 S')
      Conc = V(oox) + V(xox);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
    if strcmp(ID, 'Lac C3 D')
      Conc = V(oxx) + V(xxx);
      Mol.Conc = Conc;
      Molecules(1, i) = Mol;
    end
end

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if contains(ID, 'Lac')
        NS = Mol.NormSpectrum;
        FD = NS.FreqDomainData;
        Conc = Mol.Conc;
        FD = FD*Conc;
        CWS = Mol.ConcWtdSpectrum;
        CWS.FreqDomainData = FD;
        Mol.ConcWtdSpectrum = CWS;
        Molecules(1, i) = Mol;
    end
end

% for i = 1:nMols
%     Mol = Molecules(1, i);
%     Conc = Mol.Conc
% end

end

