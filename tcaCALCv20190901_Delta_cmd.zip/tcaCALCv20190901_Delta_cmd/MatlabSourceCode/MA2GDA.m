function GDA = MA2GDA(MA, FN)
GD.FN = FN;
GD.StudyID = '';
GD.Type = '13C NMR Multiplet';
GD.MolID = '';
GD.MeasID = '';
GD.Value = 0;

nMA = size(MA, 2);
N = 1;
for i = 1:nMA
    M = MA(1, i);
    GD.StudyID = M.SpectrumID;
    MID = M.MultipletID;
    T = split(MID, ' ');
    GD.MolID = char(T(1, 1));
    GD.MeasID = [char(T(2,1)), ' ', char(T(3,1))];
    GD.Value = M.FractionalIntensityBestFit;
    GDA(1, N) = GD;
    N = N + 1;
end
end

