function V = EstimateFourCarbonNaturalAbundance()
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx , oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();
V = zeros(1,16);
V(1, oooo) = 1.0;
end

